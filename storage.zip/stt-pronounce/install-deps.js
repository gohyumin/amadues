#!/usr/bin/env node
/**
 * 安装 pronounce.js 程序所需的依赖包
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('🚀 开始安装中文语音发音评估工具的依赖包...\n');

// 检查 Node.js 和 npm 版本
function checkVersion() {
    return new Promise((resolve, reject) => {
        exec('node --version && npm --version', (error, stdout, stderr) => {
            if (error) {
                console.error('❌ 请确保已安装 Node.js 和 npm');
                reject(error);
                return;
            }
            console.log('✅ 环境检查通过:');
            console.log(stdout.trim());
            resolve();
        });
    });
}

// 安装依赖包
function installDependencies() {
    return new Promise((resolve, reject) => {
        console.log('\n📦 正在安装依赖包...');
        
        exec('npm install', { cwd: __dirname }, (error, stdout, stderr) => {
            if (error) {
                console.error('❌ 安装依赖失败:', error.message);
                reject(error);
                return;
            }
            
            if (stderr && !stderr.includes('WARN')) {
                console.error('⚠️ 安装过程中出现警告:', stderr);
            }
            
            console.log('✅ 核心依赖安装完成');
            resolve();
        });
    });
}

// 安装可选的中文分词库
function installOptionalDeps() {
    return new Promise((resolve) => {
        console.log('\n🔤 正在安装可选的中文分词库...');
        
        exec('npm install nodejieba --save-optional', { cwd: __dirname }, (error, stdout, stderr) => {
            if (error) {
                console.log('⚠️ 中文分词库安装失败，将使用基础分词方式');
                console.log('   (这不会影响程序运行，但可能影响分词精度)');
            } else {
                console.log('✅ 中文分词库安装完成');
            }
            resolve();
        });
    });
}

// 检查音频文件
function checkAudioFile() {
    const audioFile = path.join(__dirname, '..', 'output.mp3');
    if (fs.existsSync(audioFile)) {
        console.log('✅ 找到音频文件: output.mp3');
    } else {
        console.log('⚠️ 未找到音频文件 output.mp3');
        console.log('   请确保在父目录中有要测试的音频文件');
    }
}

// 主函数
async function main() {
    try {
        await checkVersion();
        await installDependencies();
        await installOptionalDeps();
        
        console.log('\n📁 检查音频文件...');
        checkAudioFile();
        
        console.log('\n🎉 安装完成！');
        console.log('\n📋 使用说明:');
        console.log('1. 确保 output.mp3 文件在父目录中');
        console.log('2. 在 pronounce.js 中修改 reference_text 为你的音频内容');
        console.log('3. 运行: node pronounce.js');
        console.log('\n💡 提示: 如果需要更精确的中文分词，程序会自动尝试使用 nodejieba');
        
    } catch (error) {
        console.error('\n❌ 安装过程中出现错误:', error.message);
        process.exit(1);
    }
}

// 如果直接运行此脚本
if (require.main === module) {
    main();
}

module.exports = { main };