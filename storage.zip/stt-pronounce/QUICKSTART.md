# STT Pronunciation Assessment Service - 启动指南

## 快速启动

1. 安装依赖:
```bash
npm install
```

2. 创建环境配置:
```bash
cp .env.example .env
```

3. 编辑 .env 文件，设置你的语音服务密钥

4. 启动服务:
```bash
npm start
```

5. 测试服务:
```bash
npm test
```

## 服务地址
- 主服务: http://localhost:3001
- 健康检查: http://localhost:3001/health
- API 文档: http://localhost:3001/docs

## Docker 部署
```bash
docker-compose up -d
```