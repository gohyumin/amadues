// 测试文件 - test.js
const fs = require('fs');
const path = require('path');
const FormData = require('form-data');
const axios = require('axios');

// 测试配置
const BASE_URL = process.env.TEST_BASE_URL || 'http://localhost:3001';
const API_KEY = process.env.API_KEY || 'changeme';

console.log('🧪 开始测试 STT Pronunciation Assessment Service');
console.log(`📍 测试服务器: ${BASE_URL}`);

async function runTests() {
    try {
        // 测试 1: 健康检查
        console.log('\n1. 测试健康检查...');
        const healthResponse = await axios.get(`${BASE_URL}/health`);
        console.log('✅ 健康检查通过:', healthResponse.data);

        // 测试 2: 获取支持的语言
        console.log('\n2. 测试获取支持的语言...');
        const languagesResponse = await axios.get(`${BASE_URL}/languages`, {
            headers: { 'x-api-key': API_KEY }
        });
        console.log('✅ 语言列表获取成功:', languagesResponse.data);

        // 测试 3: API 文档
        console.log('\n3. 测试 API 文档...');
        const docsResponse = await axios.get(`${BASE_URL}/docs`);
        console.log('✅ API 文档获取成功');

        // 测试 4: 发音评估 (需要测试音频文件)
        console.log('\n4. 测试发音评估...');
        
        // 检查是否存在测试音频文件
        const testAudioPath = path.join(__dirname, '..', 'testing.wav');
        if (fs.existsSync(testAudioPath)) {
            const form = new FormData();
            form.append('audio', fs.createReadStream(testAudioPath));
            form.append('referenceText', '各个国家有各个国家的国歌');
            form.append('language', 'zh-CN');

            const assessmentResponse = await axios.post(`${BASE_URL}/pronunciation-assessment`, form, {
                headers: { 
                    'x-api-key': API_KEY,
                    ...form.getHeaders()
                },
                timeout: 60000 // 60秒超时
            });
            
            console.log('✅ 发音评估成功');
            console.log('评估结果:', JSON.stringify(assessmentResponse.data, null, 2));
        } else {
            console.log('⚠️ 跳过发音评估测试 - 未找到测试音频文件 testing.wav');
        }

        // 测试 5: 错误处理
        console.log('\n5. 测试错误处理...');
        
        try {
            // 测试无效 API Key
            await axios.get(`${BASE_URL}/languages`, {
                headers: { 'x-api-key': 'invalid_key' }
            });
        } catch (error) {
            if (error.response && error.response.status === 401) {
                console.log('✅ API Key 验证正常工作');
            } else {
                console.log('❌ API Key 验证测试失败');
            }
        }

        try {
            // 测试缺少必需参数
            const form = new FormData();
            form.append('referenceText', '');
            
            await axios.post(`${BASE_URL}/pronunciation-assessment`, form, {
                headers: { 
                    'x-api-key': API_KEY,
                    ...form.getHeaders()
                }
            });
        } catch (error) {
            if (error.response && error.response.status === 400) {
                console.log('✅ 参数验证正常工作');
            } else {
                console.log('❌ 参数验证测试失败');
            }
        }

        console.log('\n🎉 所有测试完成!');

    } catch (error) {
        console.error('❌ 测试失败:', error.message);
        if (error.response) {
            console.error('响应状态:', error.response.status);
            console.error('响应数据:', error.response.data);
        }
        process.exit(1);
    }
}

// 运行测试
runTests();