# STT Pronunciation Assessment Microservice

认知服务的语音发音评估微服务，提供 RESTful API 接口，可以对中文、英文等多种语言音频进行准确度、流畅度、完整度和韵律的评估。

## 🚀 快速开始

### 1. 环境要求
- Node.js >= 16.0.0
- npm >= 8.0.0
- 有效的语音服务密钥和区域

### 2. 安装依赖

```bash
# 运行自动安装脚本
node install-deps.js

# 或手动安装
npm install
```

### 3. 环境配置

复制环境变量模板并配置：
```bash
cp .env.example .env
```

编辑 `.env` 文件：
```bash
# 语音服务配置
SPEECH_KEY=your_speech_service_key_here
REGION=southeastasia

# API 安全配置
API_KEY=your_secure_api_key_here

# 服务器配置
PORT=3001
NODE_ENV=production
```

### 4. 启动服务

```bash
# 开发模式
npm run dev

# 生产模式
npm start
```

服务启动后，访问 http://localhost:3001/health 检查服务状态。

## 📡 API 接口

### 基础信息
- **服务地址**: `http://localhost:3001`
- **认证方式**: API Key (Header: `x-api-key`)
- **内容类型**: `multipart/form-data` (文件上传)

### 主要端点

#### 1. 发音评估
```http
POST /pronunciation-assessment
```

**请求头:**
```
x-api-key: your-api-key
Content-Type: multipart/form-data
```

**请求参数:**
- `audio` (文件): 音频文件 (WAV 格式，最大 10MB)
- `referenceText` (字符串): 参考文本
- `language` (字符串): 语言代码，默认 `zh-CN`

**响应示例:**
```json
{
  "success": true,
  "data": {
    "overall": {
      "pronunciationScore": 85,
      "accuracyScore": 88,
      "completenessScore": 90,
      "fluencyScore": 82,
      "prosodyScore": 80
    },
    "words": [
      {
        "index": 1,
        "word": "各个",
        "accuracyScore": 92,
        "errorType": "正确",
        "errorTypeEn": "None"
      }
    ],
    "recognizedText": "各个国家有各个国家的国歌",
    "referenceText": "各个国家有各个国家的国歌",
    "language": "zh-CN",
    "timestamp": "2023-12-07T10:30:45.123Z"
  },
  "processingTime": "2341ms"
}
```

#### 2. 支持的语言
```http
GET /languages
```

#### 3. 健康检查
```http
GET /health
```

#### 4. API 文档
```http
GET /docs
```

## 🔧 使用示例

### cURL 示例
```bash
curl -X POST "http://localhost:3001/pronunciation-assessment" ^
  -H "x-api-key: mykey" ^
  -F "audio=@D:/Labmem/qwan-image/testing.wav" ^
  -F "referenceText=各个国家有各个国家的国歌" ^
  -F "language=zh-CN"
```

### JavaScript/Node.js 示例
```javascript
const FormData = require('form-data');
const fs = require('fs');
const axios = require('axios');

const form = new FormData();
form.append('audio', fs.createReadStream('your-audio.wav'));
form.append('referenceText', '各个国家有各个国家的国歌');
form.append('language', 'zh-CN');

const response = await axios.post('http://localhost:3001/pronunciation-assessment', form, {
  headers: {
    'x-api-key': 'your-api-key',
    ...form.getHeaders()
  }
});

console.log(response.data);
```

### Python 示例
```python
import requests

url = 'http://localhost:3001/pronunciation-assessment'
headers = {'x-api-key': 'your-api-key'}
files = {'audio': open('your-audio.wav', 'rb')}
data = {
    'referenceText': '各个国家有各个国家的国歌',
    'language': 'zh-CN'
}

response = requests.post(url, headers=headers, files=files, data=data)
print(response.json())
```

## � Docker 部署

### 使用 Docker
```bash
# 构建镜像
docker build -t stt-pronounce-service .

# 运行容器
docker run -p 3001:3001 --env-file .env stt-pronounce-service
```

### 使用 Docker Compose
```bash
# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 📊 支持的语言

| 语言代码 | 语言名称 | 本地名称 | 支持特性 |
|---------|---------|---------|----------|
| zh-CN   | Chinese (Simplified) | 中文（简体） | 准确度、流畅度、完整度、韵律 |
| en-US   | English (US) | English | 准确度、流畅度、完整度、韵律 |
| ja-JP   | Japanese | 日本語 | 准确度、流畅度、完整度 |
| ko-KR   | Korean | 한국어 | 准确度、流畅度、完整度 |

## 📁 项目结构

```
stt-pronounce/
├── server.js                 # 主服务器文件
├── pronunciation-service.js  # 发音评估核心服务
├── pronounce.js             # 原始脚本（向后兼容）
├── package.json             # 项目配置
├── Dockerfile               # Docker 配置
├── docker-compose.yml       # Docker Compose 配置
├── .env.example             # 环境变量模板
├── test.js                  # 测试脚本
├── install-deps.js          # 依赖安装脚本
└── README.md                # 文档
```

## � 安全考虑

1. **API 密钥**: 使用强密码作为 API_KEY
2. **HTTPS**: 生产环境建议使用 HTTPS
3. **文件大小限制**: 音频文件限制为 10MB
4. **格式验证**: 仅支持 WAV 格式音频文件
5. **临时文件**: 自动清理临时文件避免磁盘空间问题

## 🧪 测试

运行测试脚本：
```bash
npm test
```

测试包括：
- 健康检查
- API 认证
- 语言列表获取
- 发音评估功能（需要测试音频文件）
- 错误处理

## 📊 评估指标说明

### 总体评估
- **总体发音分数 (pronunciationScore)**: 综合评分 (0-100)
- **准确度分数 (accuracyScore)**: 发音准确度 (0-100)
- **完整度分数 (completenessScore)**: 内容完整度 (0-100)
- **流畅度分数 (fluencyScore)**: 语音流畅度 (0-100)
- **韵律分数 (prosodyScore)**: 语音韵律 (0-100)

### 单词级别分析
- **正确**: 发音正确
- **多余**: 识别到但不应存在的单词
- **遗漏**: 应该说但未识别到的单词
- **发音错误**: 识别到但发音不正确的单词

## 🛠️ 故障排除

### 常见问题

1. **服务连接失败**
   - 检查 `SPEECH_KEY` 是否正确
   - 确认 `REGION` 设置正确
   - 检查网络连接

2. **音频文件格式错误**
   - 确保使用 WAV 格式
   - 文件大小不超过 10MB
   - 音频质量清晰

3. **依赖安装失败**
   - 更新 Node.js 到最新 LTS 版本
   - 清除 npm 缓存：`npm cache clean --force`
   - 使用淘宝镜像：`npm install --registry=https://registry.npm.taobao.org`

### 日志查看
```bash
# Docker 环境
docker-compose logs -f stt-pronounce-service

# 本地开发
npm run dev  # 包含详细日志输出
```

## � 中文分词支持

### 自动分词
程序支持两种中文分词方式：

1. **专业分词 (推荐)**: 使用 nodejieba 库
2. **基础分词**: 逐字分割方式

### 安装专业分词库
```bash
npm install nodejieba --save-optional
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## � 许可证

MIT License

---

## 💡 从原始脚本迁移

如果你之前使用的是原始的 `pronounce.js` 脚本，现在可以：

1. **继续使用原始脚本**: `node pronounce.js` （向后兼容）
2. **使用新的微服务**: 启动 HTTP 服务并通过 API 调用

### 原始脚本使用方法
```javascript
// 修改 pronounce.js 中的配置
var reference_text = "你的音频内容文本";
```

然后运行：
```bash
npm start  # 启动微服务
# 或
node pronounce.js  # 运行原始脚本
```

---

💡 **提示**: 为了获得最佳的评估效果，请使用清晰的 WAV 格式音频文件，并确保参考文本与音频内容完全匹配。