const express = require('express');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs-extra');
const path = require('path');
require('dotenv').config();

const PronunciationAssessmentService = require('./pronunciation-service');

const app = express();
const port = process.env.PORT || 3001;

// 中间件
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// 配置项
const KEY = process.env.SPEECH_KEY;
const REGION = process.env.REGION || 'southeastasia';
const API_KEY = process.env.API_KEY || 'changeme';

// 验证必要的环境变量
if (!KEY) {
    console.error('Error: SPEECH_KEY environment variable is required');
    process.exit(1);
}

// 创建临时文件目录
const tempDir = path.join(__dirname, 'temp');
fs.ensureDirSync(tempDir);

// 配置文件上传
const storage = multer.memoryStorage();
const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 10 * 1024 * 1024, // 10MB limit
    },
    fileFilter: (req, file, cb) => {
        // 检查文件类型 - 接受 audio/* 和常见音频文件扩展名
        const isAudioMime = file.mimetype.startsWith('audio/');
        const isWavFile = file.originalname.toLowerCase().endsWith('.wav');
        const isAudioFile = file.originalname.match(/\.(wav|mp3|m4a|aac|ogg|flac)$/i);
        
        console.log(`文件检查: ${file.originalname}, MIME: ${file.mimetype}`);
        
        if (isAudioMime || isWavFile || isAudioFile) {
            cb(null, true);
        } else {
            cb(new Error('Only audio files are allowed'), false);
        }
    }
});

// API密钥验证中间件
function validateApiKey(req, res, next) {
    const apiKey = req.headers['x-api-key'];
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API key' });
    }
    next();
}

// 发音评估服务实例
const pronunciationService = new PronunciationAssessmentService(KEY, REGION);

// 发音评估路由
app.post('/pronunciation-assessment', validateApiKey, upload.single('audio'), async (req, res) => {
    const startTime = Date.now();
    let tempFilePath = null;

    try {
        const { referenceText="各个国家有各个国家的国歌", language = 'zh-CN' } = req.body;
        
        // 验证输入
        if (!referenceText || typeof referenceText !== 'string' || referenceText.trim() === '') {
            return res.status(400).json({ 
                error: 'Bad Request: referenceText field is required and cannot be empty' 
            });
        }

        if (!req.file) {
            return res.status(400).json({ 
                error: 'Bad Request: audio file is required' 
            });
        }

        console.log(`Processing pronunciation assessment request`);
        console.log(`Reference text: ${referenceText.substring(0, 50)}${referenceText.length > 50 ? '...' : ''}`);
        console.log(`Language: ${language}`);
        console.log(`Audio file size: ${req.file.buffer.length} bytes`);

        // 验证语言代码
        const supportedLanguages = ['zh-CN', 'en-US', 'ja-JP', 'ko-KR'];
        if (!supportedLanguages.includes(language)) {
            return res.status(400).json({
                error: 'Unsupported language',
                details: `Supported languages: ${supportedLanguages.join(', ')}`
            });
        }

        // 验证音频文件格式 (Speech SDK 需要 WAV 格式)
        if (!req.file.originalname.toLowerCase().endsWith('.wav')) {
            return res.status(400).json({
                error: 'Unsupported audio format',
                details: 'Only WAV format is supported'
            });
        }

        // 执行发音评估
        const result = await pronunciationService.assessPronunciation(
            req.file.buffer,
            referenceText,
            language
        );

        const duration = Date.now() - startTime;
        console.log(`Pronunciation assessment completed in ${duration}ms`);

        // 返回结果
        res.json({
            success: true,
            data: result,
            processingTime: `${duration}ms`,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('Pronunciation Assessment Error:', error.message);
        
        const duration = Date.now() - startTime;
        
        if (error.message.includes('语音识别失败') || error.message.includes('Speech recognition failed')) {
            return res.status(400).json({
                error: 'Speech Recognition Failed',
                details: error.message,
                processingTime: `${duration}ms`
            });
        } else if (error.message.includes('Invalid subscription key')) {
            return res.status(401).json({
                error: 'Invalid subscription key',
                details: 'Please check your Speech service credentials',
                processingTime: `${duration}ms`
            });
        } else if (error.code === 'ECONNABORTED' || error.message.includes('timeout')) {
            return res.status(408).json({
                error: 'Request Timeout',
                details: 'Speech recognition request timed out',
                processingTime: `${duration}ms`
            });
        } else {
            return res.status(500).json({
                error: 'Internal Server Error',
                details: 'Pronunciation assessment processing failed',
                processingTime: `${duration}ms`
            });
        }
    } finally {
        // 清理临时文件
        if (tempFilePath && fs.existsSync(tempFilePath)) {
            try {
                fs.removeSync(tempFilePath);
            } catch (cleanupError) {
                console.warn('Failed to cleanup temp file:', cleanupError.message);
            }
        }
    }
});

// 健康检查路由
app.get('/health', (req, res) => {
    res.json({
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'stt-pronounce-service',
        version: '1.0.0',
        server: {
            region: REGION,
            connected: !!KEY
        }
    });
});

// 获取支持的语言列表
app.get('/languages', validateApiKey, (req, res) => {
    const languages = [
        {
            code: 'zh-CN',
            name: 'Chinese (Simplified)',
            nativeName: '中文（简体）',
            description: '支持中文发音评估，包括准确度、流畅度、完整度和韵律评估'
        },
        {
            code: 'en-US',
            name: 'English (US)',
            nativeName: 'English (United States)',
            description: 'Support English pronunciation assessment with accuracy, fluency, completeness and prosody'
        },
        {
            code: 'ja-JP',
            name: 'Japanese',
            nativeName: '日本語',
            description: '日本語の発音評価をサポート'
        },
        {
            code: 'ko-KR',
            name: 'Korean',
            nativeName: '한국어',
            description: '한국어 발음 평가 지원'
        }
    ];
    
    res.json({
        languages,
        total: languages.length,
        default: 'zh-CN'
    });
});

// API 文档路由
app.get('/docs', (req, res) => {
    const docs = {
        service: 'Speech-to-Text Pronunciation Assessment Service',
        version: '1.0.0',
        description: 'Pronunciation assessment microservice with REST API',
        endpoints: [
            {
                method: 'POST',
                path: '/pronunciation-assessment',
                description: 'Upload audio file and get pronunciation assessment',
                headers: {
                    'x-api-key': 'Required: Your API key',
                    'Content-Type': 'multipart/form-data'
                },
                body: {
                    audio: 'Required: Audio file (WAV format)',
                    referenceText: 'Required: Reference text to compare against',
                    language: 'Optional: Language code (default: zh-CN)'
                },
                response: {
                    success: 'boolean',
                    data: {
                        overall: {
                            pronunciationScore: 'Overall pronunciation score (0-100)',
                            accuracyScore: 'Accuracy score (0-100)',
                            completenessScore: 'Completeness score (0-100)', 
                            fluencyScore: 'Fluency score (0-100)',
                            prosodyScore: 'Prosody score (0-100)'
                        },
                        words: 'Array of word-level analysis',
                        recognizedText: 'Text recognized from audio',
                        referenceText: 'Original reference text',
                        language: 'Language code used',
                        timestamp: 'ISO timestamp'
                    },
                    processingTime: 'Processing duration'
                }
            },
            {
                method: 'GET',
                path: '/languages',
                description: 'Get supported languages list',
                headers: {
                    'x-api-key': 'Required: Your API key'
                }
            },
            {
                method: 'GET',
                path: '/health',
                description: 'Health check endpoint'
            }
        ],
        examples: {
            curl_example: `curl -X POST "http://localhost:3001/pronunciation-assessment" \\
  -H "x-api-key: your-api-key" \\
  -F "audio=@your-audio.wav" \\
  -F "referenceText=各个国家有各个国家的国歌" \\
  -F "language=zh-CN"`
        }
    };
    
    res.json(docs);
});

// 错误处理中间件
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    
    if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
            return res.status(413).json({
                error: 'File Too Large',
                details: 'Audio file size must be under 10MB'
            });
        }
        return res.status(400).json({
            error: 'File Upload Error',
            details: err.message
        });
    }
    
    // 处理文件类型错误
    if (err.message === 'Only audio files are allowed') {
        return res.status(400).json({
            error: 'Invalid File Type',
            details: 'Only audio files (WAV, MP3, etc.) are allowed'
        });
    }
    
    res.status(500).json({
        error: 'Internal Server Error',
        details: 'An unexpected error occurred'
    });
});

// 404处理
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Not Found',
        details: 'The requested endpoint does not exist',
        availableEndpoints: [
            'POST /pronunciation-assessment',
            'GET /languages', 
            'GET /health',
            'GET /docs'
        ]
    });
});

// 启动服务器
app.listen(port, () => {
    console.log(`STT Pronunciation Assessment Service running on port ${port}`);
    console.log(`Region: ${REGION}`);
    console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log('Available endpoints:');
    console.log('  POST /pronunciation-assessment - Upload audio for pronunciation assessment');
    console.log('  GET /languages - Get supported languages');
    console.log('  GET /health - Health check');
    console.log('  GET /docs - API documentation');
    console.log(`Temporary files directory: ${tempDir}`);
});

// 优雅关闭
process.on('SIGTERM', () => {
    console.log('Received SIGTERM signal, shutting down gracefully...');
    // 清理临时文件目录
    try {
        fs.removeSync(tempDir);
    } catch (error) {
        console.warn('Failed to cleanup temp directory:', error.message);
    }
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('Received SIGINT signal, shutting down gracefully...');
    // 清理临时文件目录
    try {
        fs.removeSync(tempDir);
    } catch (error) {
        console.warn('Failed to cleanup temp directory:', error.message);
    }
    process.exit(0);
});

// 处理未捕获的异常
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    // 清理临时文件目录
    try {
        fs.removeSync(tempDir);
    } catch (cleanupError) {
        console.warn('Failed to cleanup temp directory:', cleanupError.message);
    }
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});