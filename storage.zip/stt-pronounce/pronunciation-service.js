// pronunciation-service.js - 发音评估核心服务模块
const sdk = require("microsoft-cognitiveservices-speech-sdk");
const _ = require("lodash");
const difflib = require("difflib");

// 可选：中文分词库
let nodejieba = null;
try {
    nodejieba = require("nodejieba");
    console.log("✅ 已加载中文分词库 nodejieba");
} catch (error) {
    console.log("⚠️ 未安装 nodejieba，将使用基础中文处理方式");
}

/**
 * 发音评估服务类
 */
class PronunciationAssessmentService {
    constructor(Key, Region) {
        this.Key = Key;
        this.Region = Region;
    }

    /**
     * 执行发音评估
     * @param {Buffer} audioBuffer - 音频文件缓冲区
     * @param {string} referenceText - 参考文本
     * @param {string} language - 语言代码，默认 'zh-CN'
     * @returns {Promise<Object>} 评估结果
     */
    async assessPronunciation(audioBuffer, referenceText, language = 'zh-CN') {
        return new Promise((resolve, reject) => {
            try {
                console.log(`📝 参考文本: ${referenceText}`);
                console.log(`🌏 语言设置: ${language}`);
                console.log(`🔊 音频大小: ${audioBuffer.length} bytes`);

                // 创建音频配置
                const audioConfig = sdk.AudioConfig.fromWavFileInput(audioBuffer);
                
                // 创建语音配置
                const speechConfig = sdk.SpeechConfig.fromSubscription(this.Key, this.Region);
                speechConfig.speechRecognitionLanguage = language;

                // 创建发音评估配置
                const pronunciationAssessmentConfig = new sdk.PronunciationAssessmentConfig(
                    referenceText,
                    sdk.PronunciationAssessmentGradingSystem.HundredMark,
                    sdk.PronunciationAssessmentGranularity.Phoneme,
                    true
                );
                pronunciationAssessmentConfig.enableProsodyAssessment = true;

                // 创建语音识别器
                const recognizer = new sdk.SpeechRecognizer(speechConfig, audioConfig);
                pronunciationAssessmentConfig.applyTo(recognizer);

                // 评估数据收集
                const scoreNumber = {
                    accuracyScore: 0,
                    fluencyScore: 0,
                    compScore: 0,
                    prosodyScore: 0,
                    pronScore: 0
                };
                
                const allWords = [];
                let currentText = [];
                let startOffset = 0;
                let recognizedWords = [];
                let fluencyScores = [];
                let prosodyScores = [];
                let durations = [];
                let jsonResult = {};

                // 识别中事件
                recognizer.recognizing = (s, e) => {
                    console.log(`(识别中) ${e.result.text}`);
                };

                // 识别完成事件
                recognizer.recognized = (s, e) => {
                    console.log(`识别到的语音内容: ${e.result.text}`);
                    
                    const pronunciationResult = sdk.PronunciationAssessmentResult.fromResult(e.result);
                    console.log(`准确度: ${pronunciationResult.accuracyScore}, 发音: ${pronunciationResult.pronunciationScore}, 完整度: ${pronunciationResult.completenessScore}, 流畅度: ${pronunciationResult.fluencyScore}${pronunciationResult.prosodyScore !== undefined ? `, 韵律: ${pronunciationResult.prosodyScore}` : ''}`);

                    jsonResult = JSON.parse(e.result.properties.getProperty(sdk.PropertyId.SpeechServiceResponse_JsonResult));
                    
                    if (jsonResult.NBest && jsonResult.NBest[0]) {
                        const nb = jsonResult.NBest[0];
                        if (nb.Words && nb.Words.length > 0) {
                            startOffset = nb.Words[0].Offset;
                            const localtext = _.map(nb.Words, (item) => item.Word.toLowerCase());
                            currentText = currentText.concat(localtext);
                            
                            fluencyScores.push(nb.PronunciationAssessment.FluencyScore);
                            if (nb.PronunciationAssessment.ProsodyScore !== undefined) {
                                prosodyScores.push(nb.PronunciationAssessment.ProsodyScore);
                            }

                            const durationList = [];
                            _.forEach(nb.Words, (word) => {
                                recognizedWords.push(word);
                                durationList.push(word.Duration);
                            });
                            durations.push(_.sum(durationList));

                            if (jsonResult.RecognitionStatus === 'Success' && nb.Words) {
                                allWords.push(...nb.Words);
                            }
                        }
                    }
                };

                // 取消事件
                recognizer.canceled = (s, e) => {
                    if (e.reason === sdk.CancellationReason.Error) {
                        console.error(`识别取消: ${e.errorDetails}`);
                        reject(new Error(`语音识别失败: ${e.errorDetails}`));
                    } else {
                        console.log("识别被取消");
                    }
                };

                // 会话开始
                recognizer.sessionStarted = (s, e) => {
                    console.log("会话开始");
                };

                // 会话结束
                recognizer.sessionStopped = (s, e) => {
                    console.log("会话结束，开始计算最终分数...");
                    
                    try {
                        const finalResult = this.calculateOverallPronunciationScore(
                            currentText,
                            referenceText,
                            language,
                            allWords,
                            recognizedWords,
                            fluencyScores,
                            prosodyScores,
                            durations,
                            startOffset,
                            jsonResult,
                            scoreNumber
                        );
                        
                        recognizer.stopContinuousRecognitionAsync();
                        recognizer.close();
                        resolve(finalResult);
                    } catch (error) {
                        reject(error);
                    }
                };

                // 开始识别
                console.log("开始语音识别和发音评估...");
                recognizer.startContinuousRecognitionAsync();

            } catch (error) {
                console.error("发音评估初始化失败:", error);
                reject(error);
            }
        });
    }

    /**
     * 计算综合发音分数
     */
    calculateOverallPronunciationScore(currentText, referenceText, language, allWords, recognizedWords, fluencyScores, prosodyScores, durations, startOffset, jsonResult, scoreNumber) {
        const resText = currentText.join(" ");
        let wholelyricsArry = [];
        let resTextArray = [];

        console.log("开始计算综合发音分数...");
        console.log("识别的文本: ", resText);
        console.log("参考文本: ", referenceText);

        if (["zh-cn"].includes(language.toLowerCase())) {
            // 中文处理逻辑
            const resTextProcessed = (resText.toLowerCase() ?? "").replace(new RegExp("[^a-zA-Z0-9\u4E00-\u9FA5']+", "g"), " ");
            const wholelyrics = (referenceText.toLowerCase() ?? "").replace(new RegExp("[^a-zA-Z0-9\u4E00-\u9FA5']+", "g"), " ");
            
            // 使用专业的中文分词库或基础分词方式
            try {
                if (nodejieba) {
                    wholelyricsArry = nodejieba.cut(wholelyrics, true).filter(word => word.trim() !== '');
                    resTextArray = nodejieba.cut(resTextProcessed, true).filter(word => word.trim() !== '');
                    console.log("使用 nodejieba 进行中文分词");
                } else {
                    wholelyricsArry = Array.from(wholelyrics.trim()).filter(char => char.trim() !== '');
                    resTextArray = Array.from(resTextProcessed.trim()).filter(char => char.trim() !== '');
                    console.log("使用基础逐字分割方式");
                }
            } catch (error) {
                console.log("中文分词处理出错，使用简单分割方式: ", error.message);
                wholelyricsArry = Array.from(wholelyrics.trim()).filter(char => char.trim() !== '');
                resTextArray = Array.from(resTextProcessed.trim()).filter(char => char.trim() !== '');
            }
        } else {
            // 英文处理逻辑
            let resTextProcessed = (resText.toLowerCase() ?? "").replace(new RegExp("[!\"#$%&()*+,-./:;<=>?@[^_`{|}~]+", "g"), "").replace(new RegExp("]+", "g"), "");
            let wholelyrics = (referenceText.toLowerCase() ?? "").replace(new RegExp("[!\"#$%&()*+,-./:;<=>?@[^_`{|}~]+", "g"), "").replace(new RegExp("]+", "g"), "");
            wholelyricsArry = wholelyrics.split(" ");
            resTextArray = resTextProcessed.split(" ");
        }

        const wholelyricsArryRes = _.map(
            _.filter(wholelyricsArry, (item) => !!item),
            (item) => item.trim()
        );
        
        console.log("参考文本分词结果: ", wholelyricsArryRes);
        console.log("识别文本分词结果: ", resTextArray);

        // 使用序列匹配器比较文本差异
        const diff = new difflib.SequenceMatcher(null, wholelyricsArryRes, resTextArray);
        const lastWords = [];
        
        for (const d of diff.getOpcodes()) {
            if (d[0] == "insert" || d[0] == "replace") {
                if (["zh-cn"].includes(language.toLowerCase())) {
                    for (let j = d[3], count = 0; j < d[4]; count++) {
                        let len = 0;
                        let bfind = false;
                        _.map(allWords, (item, index) => {
                            if ((len == j || (index + 1 < allWords.length && allWords[index].Word.length > 1 && j > len && j < len + allWords[index + 1].Word.length)) && !bfind) {
                                const wordNew = _.cloneDeep(allWords[index]);
                                if (allWords && allWords.length > 0 && allWords[index].PronunciationAssessment.ErrorType !== "Insertion") {
                                    wordNew.PronunciationAssessment.ErrorType = "Insertion";
                                }
                                lastWords.push(wordNew);
                                bfind = true;
                                j += allWords[index].Word.length;
                            }
                            len = len + item.Word.length;
                        });
                    }
                } else {
                    for (let j = d[3]; j < d[4]; j++) {
                        if (allWords && allWords.length > 0 && allWords[j].PronunciationAssessment.ErrorType !== "Insertion") {
                            allWords[j].PronunciationAssessment.ErrorType = "Insertion";
                        }
                        lastWords.push(allWords[j]);
                    }
                }
            }
            if (d[0] == "delete" || d[0] == "replace") {
                if (d[2] == wholelyricsArryRes.length && !(jsonResult.RecognitionStatus == "Success" || jsonResult.RecognitionStatus == "Failed")) {
                    continue;
                }
                for (let i = d[1]; i < d[2]; i++) {
                    const word = {
                        Word: wholelyricsArryRes[i],
                        PronunciationAssessment: {
                            ErrorType: "Omission",
                        },
                    };
                    lastWords.push(word);
                }
            }
            if (d[0] == "equal") {
                for (let k = d[3], count = 0; k < d[4]; count++) {
                    if (["zh-cn"].includes(language.toLowerCase())) {
                        let len = 0;
                        let bfind = false;
                        _.map(allWords, (item, index) => {
                            if (len >= k && !bfind) {
                                if (allWords[index].PronunciationAssessment.ErrorType !== "None") {
                                    allWords[index].PronunciationAssessment.ErrorType = "None";
                                }
                                lastWords.push(allWords[index]);
                                bfind = true;
                                k += allWords[index].Word.length;
                            }
                            len = len + item.Word.length;
                        });
                    } else {
                        lastWords.push(allWords[k]);
                        k++;
                    }
                }
            }
        }

        // 计算各项分数
        let referenceWords = [];
        if (["zh-cn"].includes(language.toLowerCase())) {
            referenceWords = allWords;
        } else {
            referenceWords = wholelyricsArryRes;
        }

        let recognizedWordsRes = [];
        _.forEach(recognizedWords, (word) => {
            if (word.PronunciationAssessment.ErrorType == "None") {
                recognizedWordsRes.push(word);
            }
        });
        
        // 完整度分数
        let compScore = Number(((recognizedWordsRes.length / referenceWords.length) * 100).toFixed(0));
        if (compScore > 100) {
            compScore = 100;
        }
        scoreNumber.compScore = compScore;

        // 准确度分数
        const accuracyScores = [];
        _.forEach(lastWords, (word) => {
            if (word && word?.PronunciationAssessment?.ErrorType != "Insertion") {
                accuracyScores.push(Number(word?.PronunciationAssessment.AccuracyScore ?? 0));
            }
        });
        scoreNumber.accuracyScore = Number((_.sum(accuracyScores) / accuracyScores.length).toFixed(0));

        // 流畅度分数
        if (startOffset) {
            const sumRes = [];
            _.forEach(fluencyScores, (x, index) => {
                sumRes.push(x * durations[index]);
            });
            scoreNumber.fluencyScore = _.sum(sumRes) / _.sum(durations);
        }

        // 韵律分数
        scoreNumber.prosodyScore = Number((_.sum(prosodyScores) / prosodyScores.length).toFixed(0));

        // 总体发音分数
        const sortScore = Object.keys(scoreNumber).sort(function (a, b) {
            return scoreNumber[a] - scoreNumber[b];
        });
        
        if (jsonResult.RecognitionStatus == "Success" || jsonResult.RecognitionStatus == "Failed") {
            scoreNumber.pronScore = Number(
                (
                    scoreNumber[sortScore["0"]] * 0.4 +
                    scoreNumber[sortScore["1"]] * 0.2 +
                    scoreNumber[sortScore["2"]] * 0.2 +
                    scoreNumber[sortScore["3"]] * 0.2
                ).toFixed(0)
            );
        } else {
            scoreNumber.pronScore = Number(
                (scoreNumber.accuracyScore * 0.5 + scoreNumber.fluencyScore * 0.5).toFixed(0)
            );
        }

        // 处理单词详细分析
        const wordAnalysis = [];
        _.forEach(lastWords, (word, index) => {
            const errorTypeMap = {
                "None": "正确",
                "Insertion": "多余", 
                "Omission": "遗漏",
                "Mispronunciation": "发音错误"
            };
            const errorType = errorTypeMap[word.PronunciationAssessment.ErrorType] || word.PronunciationAssessment.ErrorType;
            wordAnalysis.push({
                index: index + 1,
                word: word.Word,
                accuracyScore: word.PronunciationAssessment.AccuracyScore,
                errorType: errorType,
                errorTypeEn: word.PronunciationAssessment.ErrorType
            });
        });

        console.log("=== 最终评估结果 ===");
        console.log(`总体发音分数: ${scoreNumber.pronScore}, 准确度分数: ${scoreNumber.accuracyScore}, 完整度分数: ${scoreNumber.compScore}, 流畅度分数: ${scoreNumber.fluencyScore}, 韵律分数: ${scoreNumber.prosodyScore}`);

        return {
            overall: {
                pronunciationScore: scoreNumber.pronScore,
                accuracyScore: scoreNumber.accuracyScore,
                completenessScore: scoreNumber.compScore,
                fluencyScore: Math.round(scoreNumber.fluencyScore),
                prosodyScore: scoreNumber.prosodyScore
            },
            words: wordAnalysis,
            recognizedText: resText,
            referenceText: referenceText,
            language: language,
            timestamp: new Date().toISOString()
        };
    }
}

module.exports = PronunciationAssessmentService;