#!/usr/bin/env node
/**
 * 测试配置和环境的脚本
 */

const fs = require('fs');
const path = require('path');

console.log('🔍 正在检查环境配置...\n');

// 检查 Node.js 版本
const nodeVersion = process.version;
console.log(`Node.js 版本: ${nodeVersion}`);

// 检查必要的依赖包
const requiredPackages = [
    'microsoft-cognitiveservices-speech-sdk',
    'lodash',
    'difflib'
];

const optionalPackages = [
    'nodejieba'
];

console.log('\n📦 检查必要依赖包:');
requiredPackages.forEach(pkg => {
    try {
        require(pkg);
        console.log(`✅ ${pkg}`);
    } catch (error) {
        console.log(`❌ ${pkg} - 未安装`);
    }
});

console.log('\n📦 检查可选依赖包:');
optionalPackages.forEach(pkg => {
    try {
        require(pkg);
        console.log(`✅ ${pkg} - 已安装（提升中文分词精度）`);
    } catch (error) {
        console.log(`⚠️ ${pkg} - 未安装（使用基础分词方式）`);
    }
});

// 检查音频文件
console.log('\n🎵 检查音频文件:');
const audioFile = path.join(__dirname, '..', 'output.mp3');
if (fs.existsSync(audioFile)) {
    const stats = fs.statSync(audioFile);
    const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
    console.log(`✅ output.mp3 - 文件大小: ${fileSizeMB} MB`);
} else {
    console.log('❌ output.mp3 - 文件不存在');
    console.log('   请确保音频文件在父目录中');
}

// 检查配置文件
console.log('\n📄 检查配置文件:');
const configFiles = ['package.json', 'pronounce.js', 'README.md'];
configFiles.forEach(file => {
    const filePath = path.join(__dirname, file);
    if (fs.existsSync(filePath)) {
        console.log(`✅ ${file}`);
    } else {
        console.log(`❌ ${file} - 文件缺失`);
    }
});

// Azure 配置提醒
console.log('\n🔑 Azure 配置提醒:');
console.log('请确保在 pronounce.js 中配置了有效的:');
console.log('- Azure 语音服务订阅密钥');
console.log('- Azure 语音服务区域 (如: southeastasia)');
console.log('- 正确的参考文本内容');

console.log('\n📋 下一步操作:');
if (!fs.existsSync(audioFile)) {
    console.log('1. 将音频文件重命名为 output.mp3 并放在父目录');
}
console.log('2. 在 pronounce.js 中设置正确的参考文本');
console.log('3. 运行: node pronounce.js');

console.log('\n✨ 配置检查完成！');