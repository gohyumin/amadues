# n8n Storage Microservice Workflow

这个n8n workflow用于处理Storage Microservice的API请求，通过webhook接收请求，然后根据不同的endpoint和method进行路由处理。

## Workflow 结构

### 1. Webhook Listener (入口节点)
- **类型**: Webhook
- **路径**: `/webhook-test/storage-service`
- **方法**: POST
- **功能**: 接收来自前端demo的所有API请求

### 2. API Router (核心路由节点)
- **类型**: Switch
- **功能**: 根据请求的`endpoint`和`method`进行条件判断和路由
- **条件分支**:
  - Health Check: `/health`
  - User Preferences: `/user-preferences` + HTTP方法
  - User Statistics: `/user-statistics` + HTTP方法  
  - Chat Histories: `/chat-histories` + HTTP方法
  - Stats: `/stats`
  - Clear All: `/clear-all`

### 3. HTTP Request 节点们
每个API endpoint都有对应的HTTP Request节点：
- **Health Check**: `GET http://localhost:3005/health`
- **User Preferences**: 
  - POST: `POST http://localhost:3005/user-preferences`
  - GET: `GET http://localhost:3005/user-preferences/{userId}`
  - PUT: `PUT http://localhost:3005/user-preferences/{userId}`
  - DELETE: `DELETE http://localhost:3005/user-preferences/{userId}`
- **User Statistics**: 类似结构
- **Chat Histories**: 类似结构
- **Stats**: `GET http://localhost:3005/stats`
- **Clear All**: `POST http://localhost:3005/clear-all`

### 4. Response 节点
- **Return Response**: 返回成功响应
- **Error Response**: 返回错误响应（未支持的API端点）

## 请求格式

前端发送到webhook的请求格式：
```json
{
  "endpoint": "/user-preferences",
  "method": "POST",
  "data": {
    "userId": "123",
    "age": 25,
    "country": "CN",
    "interests": ["AI", "Programming"],
    "level": "intermediate",
    "nativeLanguage": "zh",
    "targetLanguage": "en"
  }
}
```

## 安装和配置

1. **导入workflow**:
   - 在n8n界面中选择 "Import from File"
   - 选择 `n8n-storage-workflow.json` 文件
   - 点击导入

2. **配置webhook URL**:
   - 确保webhook节点的路径设置为: `storage-service`
   - 完整的webhook URL将会是: `https://你的n8n域名/webhook/storage-service`

3. **配置后端服务地址**:
   - 修改所有HTTP Request节点中的URL
   - 将 `http://localhost:3005` 替换为你的实际storage服务地址

4. **激活workflow**:
   - 点击右上角的激活开关
   - 确保workflow状态为"Active"

## 测试

1. **使用demo.html测试**:
   - 确保demo.html中的WEBHOOK_URL指向正确的n8n webhook地址
   - 在浏览器中打开demo.html进行各种API操作测试

2. **直接测试webhook**:
   ```bash
   curl -X POST https://你的n8n域名/webhook/storage-service \
     -H "Content-Type: application/json" \
     -d '{"endpoint": "/health", "method": "GET"}'
   ```

## 注意事项

1. **网络连接**: 确保n8n服务器能够访问你的storage microservice
2. **端口配置**: 确认storage service运行在端口3005
3. **CORS设置**: 如果出现跨域问题，检查storage service的CORS配置
4. **错误处理**: workflow包含了基本的错误处理，未匹配的请求会返回400错误

## 扩展

要添加新的API端点：
1. 在Switch节点中添加新的条件
2. 创建对应的HTTP Request节点
3. 连接到Return Response节点
4. 重新激活workflow

## 监控和日志

- 在n8n的执行历史中可以查看每次请求的处理情况
- 可以设置webhook的测试URL进行调试
- 建议开启n8n的执行日志记录功能