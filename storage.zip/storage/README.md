# Storage Microservice - 暂存仓库微服务

基于内存的暂存仓库微服务，用于减少SQL I/O开销，提供用户偏好、用户统计和聊天历史的临时存储服务。

## 功能特性

- 🚀 **高性能内存存储** - 数据存储在内存中，读写速度极快
- 👤 **用户偏好管理** - 存储用户个人偏好设置
- 📊 **用户统计追踪** - 记录学习进度和成绩统计
- 💬 **聊天历史管理** - 保存用户与AI助手的对话记录
- 🔍 **数据验证** - 严格的数据类型检查和验证
- 📦 **容器化部署** - 支持Docker容器部署
- 🔧 **RESTful API** - 完整的增删改查操作
- 🏥 **健康检查** - 服务状态监控端点

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 启动服务

```bash
# 生产模式
npm start

# 开发模式（自动重启）
npm run dev

# 运行测试
npm test
```

服务将在 `http://localhost:3005` 启动

### 3. Docker部署

#### 构建镜像
```bash
docker build -t storage-service .
```

#### 运行单个容器
```bash
docker run -p 3005:3005 storage-service
```

#### 使用 Docker Compose
```bash
docker-compose up -d
```

## API文档

### 🏥 健康检查

**GET** `/api/health`

#### 响应
```json
{
  "success": true,
  "status": "healthy",
  "timestamp": "2025-09-19T10:30:00.000Z"
}
```

### 📊 系统统计

**GET** `/api/stats`

#### 响应
```json
{
  "success": true,
  "data": {
    "userPreferences": 10,
    "userStatistics": 8,
    "totalChatMessages": 156,
    "usersWithChatHistory": 5
  }
}
```

## 👤 用户偏好 API

### 创建用户偏好

**POST** `/api/user-preferences`

#### 请求体
```json
{
  "user_id": "user_123",
  "age": 25,
  "country": "China",
  "interest1": "Technology",
  "interest2": "Music",
  "level": "Intermediate",
  "native_language": "Chinese",
  "target_language": "English"
}
```

#### 响应
```json
{
  "success": true,
  "data": {
    "user_id": "user_123",
    "age": 25,
    "country": "China",
    "interest1": "Technology",
    "interest2": "Music",
    "level": "Intermediate",
    "native_language": "Chinese",
    "target_language": "English"
  }
}
```

### 获取用户偏好

**GET** `/api/user-preferences/{userId}`

### 更新用户偏好

**PUT** `/api/user-preferences/{userId}`

#### 请求体
```json
{
  "age": 26,
  "level": "Advanced"
}
```

### 删除用户偏好

**DELETE** `/api/user-preferences/{userId}`

### 获取所有用户偏好

**GET** `/api/user-preferences`

## 📈 用户统计 API

### 创建用户统计

**POST** `/api/user-statistics`

#### 请求体
```json
{
  "user_id": "user_123",
  "accuracy": 85,
  "intonation": 78,
  "words_learned": 150
}
```

#### 响应
```json
{
  "success": true,
  "data": {
    "user_id": "user_123",
    "accuracy": 85,
    "intonation": 78,
    "words_learned": 150,
    "timestamp": "2025-09-19T10:30:00.000Z"
  }
}
```

### 获取用户统计

**GET** `/api/user-statistics/{userId}`

### 更新用户统计

**PUT** `/api/user-statistics/{userId}`

### 删除用户统计

**DELETE** `/api/user-statistics/{userId}`

### 获取所有用户统计

**GET** `/api/user-statistics`

## 💬 聊天历史 API

### 添加聊天消息

**POST** `/api/chat-histories`

#### 请求体
```json
{
  "user_id": "user_123",
  "sender": "user",
  "message": {
    "type": "text",
    "content": "Hello, I want to practice pronunciation",
    "audio_path": "/uploads/user_audio_001.wav"
  }
}
```

#### 响应
```json
{
  "success": true,
  "data": {
    "id": "uuid-generated-id",
    "user_id": "user_123",
    "sender": "user",
    "timestamp": "2025-09-19T10:30:00.000Z",
    "message": {
      "type": "text",
      "content": "Hello, I want to practice pronunciation",
      "audio_path": "/uploads/user_audio_001.wav"
    }
  }
}
```

### 获取用户聊天历史

**GET** `/api/chat-histories/{userId}`

#### 响应
```json
{
  "success": true,
  "data": [
    {
      "id": "msg-001",
      "user_id": "user_123",
      "sender": "user",
      "timestamp": "2025-09-19T10:30:00.000Z",
      "message": {
        "type": "text",
        "content": "Hello, I want to practice pronunciation",
        "audio_path": "/uploads/user_audio_001.wav"
      }
    }
  ],
  "count": 1
}
```

### 获取特定消息

**GET** `/api/chat-histories/message/{messageId}`

### 删除聊天消息

**DELETE** `/api/chat-histories/message/{messageId}`

### 清空用户聊天历史

**DELETE** `/api/chat-histories/{userId}`

## 🔧 管理操作

### 清空所有数据

**POST** `/api/clear-all`

#### 响应
```json
{
  "success": true,
  "message": "All data cleared successfully"
}
```

## 使用示例

### curl 示例

#### 创建用户偏好
```bash
curl -X POST http://localhost:3005/api/user-preferences ^
  -H "Content-Type: application/json" ^
  -d '{ "user_id": "demo_user", "age": 25, "country": "China", "interest1": "Programming", "interest2": "Music", "level":  "Intermediate", "native_language": "Chinese", "target_language": "English" }'
```

#### 添加聊天消息
```bash
curl -X POST http://localhost:3005/api/chat-histories ^
  -H "Content-Type: application/json" ^
  -d '{ "user_id": "demo_user", "sender": "user", "message": { "type": "text", "content": "Hello, world!", "audio_path": "/uploads/hello.wav" } }'
```

### JavaScript/Node.js 示例

```javascript
const axios = require('axios');

const BASE_URL = 'http://localhost:3005/api';

// 创建用户偏好
async function createUserPreference() {
  try {
    const response = await axios.post(`${BASE_URL}/user-preferences`, {
      user_id: 'demo_user',
      age: 25,
      country: 'China',
      interest1: 'Programming',
      interest2: 'Music',
      level: 'Intermediate',
      native_language: 'Chinese',
      target_language: 'English'
    });
    
    console.log('用户偏好创建成功:', response.data);
  } catch (error) {
    console.error('创建失败:', error.response?.data || error.message);
  }
}

// 获取用户聊天历史
async function getChatHistory(userId) {
  try {
    const response = await axios.get(`${BASE_URL}/chat-histories/${userId}`);
    console.log('聊天历史:', response.data);
  } catch (error) {
    console.error('获取失败:', error.response?.data || error.message);
  }
}

createUserPreference();
getChatHistory('demo_user');
```

### Python 示例

```python
import requests
import json

BASE_URL = "http://localhost:3005/api"

def create_user_statistic():
    url = f"{BASE_URL}/user-statistics"
    data = {
        "user_id": "demo_user",
        "accuracy": 92,
        "intonation": 87,
        "words_learned": 345
    }
    
    response = requests.post(url, json=data)
    
    if response.status_code == 201:
        print("用户统计创建成功:", response.json())
    else:
        print(f"创建失败: {response.status_code} - {response.text}")

def get_system_stats():
    url = f"{BASE_URL}/stats"
    response = requests.get(url)
    
    if response.status_code == 200:
        print("系统统计:", response.json())
    else:
        print(f"获取失败: {response.status_code}")

create_user_statistic()
get_system_stats()
```

## 数据结构说明

### 用户偏好 (UserPreference)
- `user_id`: 用户ID (字符串)
- `age`: 年龄 (整数)
- `country`: 国家 (字符串)
- `interest1`: 兴趣1 (字符串)
- `interest2`: 兴趣2 (字符串)
- `level`: 等级 (字符串)
- `native_language`: 母语 (字符串)
- `target_language`: 目标语言 (字符串)

### 用户统计 (UserStatistic)
- `user_id`: 用户ID (字符串)
- `accuracy`: 准确率 (整数)
- `intonation`: 语调分数 (整数)
- `words_learned`: 已学词汇数 (整数)
- `timestamp`: 时间戳 (自动生成)

### 聊天消息 (ChatMessage)
- `id`: 消息ID (自动生成UUID)
- `user_id`: 用户ID (字符串)
- `sender`: 发送者 ("user" 或 "assistant")
- `timestamp`: 时间戳 (自动生成)
- `message`: 消息内容对象
  - `type`: 消息类型 (字符串)
  - `content`: 消息内容 (字符串)
  - `audio_path`: 音频路径 (字符串)

## 错误处理

服务提供详细的错误信息：

| 状态码 | 描述 |
|--------|------|
| 200 | 请求成功 |
| 201 | 创建成功 |
| 400 | 请求参数错误或数据验证失败 |
| 404 | 资源未找到 |
| 500 | 服务器内部错误 |

### 错误响应格式
```json
{
  "success": false,
  "error": "错误描述信息",
  "timestamp": "2025-09-19T10:30:00.000Z"
}
```

## 环境配置

### 环境变量
- `PORT`: 服务端口 (默认: 3005)
- `NODE_ENV`: 运行环境 (development/production)

### Docker 环境变量
```yaml
environment:
  - NODE_ENV=production
  - PORT=3005
```

## 测试

运行完整的测试套件：
```bash
npm test
```

测试覆盖：
- ✅ 健康检查
- ✅ 用户偏好 CRUD 操作
- ✅ 用户统计 CRUD 操作
- ✅ 聊天历史管理
- ✅ 数据验证
- ✅ 错误处理

## 部署注意事项

1. **内存使用**: 所有数据存储在内存中，重启后数据会丢失
2. **扩展性**: 适用于临时存储和缓存场景
3. **性能**: 读写速度极快，适合高频访问的数据
4. **容量限制**: 注意内存使用量，避免过度存储大量数据
5. **生产环境**: 建议配合持久化数据库使用

## API 客户端集成

### 前端集成示例

```javascript
class StorageService {
  constructor(baseURL = 'http://localhost:3005/api') {
    this.baseURL = baseURL;
  }

  async createUserPreference(userPreference) {
    const response = await fetch(`${this.baseURL}/user-preferences`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(userPreference)
    });
    return response.json();
  }

  async addChatMessage(message) {
    const response = await fetch(`${this.baseURL}/chat-histories`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(message)
    });
    return response.json();
  }

  async getChatHistory(userId) {
    const response = await fetch(`${this.baseURL}/chat-histories/${userId}`);
    return response.json();
  }
}

// 使用示例
const storage = new StorageService();
```

## 许可证

MIT License