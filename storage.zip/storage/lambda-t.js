import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import {
  DynamoDBDocumentClient,
  PutCommand,
  GetCommand,
  DeleteCommand,
  QueryCommand
} from "@aws-sdk/lib-dynamodb";
import crypto from "crypto";

// DynamoDB setup
const client = new DynamoDBClient({ region: "ap-southeast-1" });
const ddbDocClient = DynamoDBDocumentClient.from(client);

// 生成唯一 ID
const generateId = () => crypto.randomUUID();

export const handler = async (event) => {
  console.log("Received event:", JSON.stringify(event, null, 2));

  let payload = event.body;
  if (typeof payload === "string") {
    try {
      payload = JSON.parse(payload);
    } catch (e) {
      return { statusCode: 400, body: JSON.stringify({ error: "Invalid JSON" }) };
    }
  }

  const method = payload?.httpMethod;
  const { table, users_id, ...body } = payload || {};

  if (!table) {
    return { statusCode: 400, body: JSON.stringify({ error: "Table name required" }) };
  }

  try {
    // =============== POST ===============
    if (method === "POST") {
      let item = { users_id };

      switch (table) {
        case "users_statistics":
          const { accuracy, intonation, words_learned, timestamp } = body;
          item = { ...item, accuracy, intonation, words_learned, timestamp };
          break;
        case "chat_logs":
          const { sender, message, timestamp: chatTime } = body;
          item = {
            ...item,
            chatbot_logs_id: generateId(), // sort key
            sender,
            timestamp: chatTime,
            message
          };
          break;
        case "words":
          const { words_id, native_word, target_word, timestamp: wordTime } = body;
          item = { ...item, words_id, native_word, target_word, timestamp: wordTime };
          break;
        case "users_preferences":
          const { age, country, interest1, interest2, native_language, target_language, level } = body;
          item = { ...item, age, country, interest1, interest2, native_language, target_language, level };
          break;
        default:
          return { statusCode: 400, body: JSON.stringify({ error: "Unsupported table" }) };
      }

      await ddbDocClient.send(new PutCommand({ TableName: table, Item: item }));
      return { statusCode: 201, body: JSON.stringify({ message: `Item inserted into ${table}`, item }) };
    }

    // =============== GET ===============
    if (method === "GET") {
      if (!users_id) return { statusCode: 400, body: JSON.stringify({ error: "users_id required" }) };

      // chat_logs
      if (table === "chat_logs") {
        const { chatbot_logs_id } = body;
        if (chatbot_logs_id) {
          const result = await ddbDocClient.send(new GetCommand({
            TableName: table,
            Key: { users_id, chatbot_logs_id }
          }));
          return { statusCode: 200, body: JSON.stringify(result.Item || {}) };
        } else {
          const result = await ddbDocClient.send(new QueryCommand({
            TableName: table,
            KeyConditionExpression: "users_id = :uid",
            ExpressionAttributeValues: { ":uid": users_id }
          }));
          return { statusCode: 200, body: JSON.stringify(result.Items || []) };
        }
      }

      // words
      if (table === "words") {
        const { words_id } = body;
        if (words_id) {
          // 单条记录
          const result = await ddbDocClient.send(new GetCommand({
            TableName: table,
            Key: { users_id, words_id }
          }));
          return { statusCode: 200, body: JSON.stringify(result.Item || {}) };
        } else {
          // 查询用户所有单词记录
          const result = await ddbDocClient.send(new QueryCommand({
            TableName: table,
            KeyConditionExpression: "users_id = :uid",
            ExpressionAttributeValues: { ":uid": users_id }
          }));
          return { statusCode: 200, body: JSON.stringify(result.Items || []) };
        }
      }

      // 其他 table: users_statistics, users_preferences 等
      const result = await ddbDocClient.send(new GetCommand({
        TableName: table,
        Key: { users_id }
      }));
      return { statusCode: 200, body: JSON.stringify(result.Item || {}) };
    }

    // =============== PUT ===============
    if (method === "PUT") {
      if (!users_id) return { statusCode: 400, body: JSON.stringify({ error: "users_id required" }) };

      let item = { users_id, ...body };

      if (table === "chat_logs" && !body.chatbot_logs_id)
        return { statusCode: 400, body: JSON.stringify({ error: "chatbot_logs_id required" }) };

      if (table === "words" && !body.words_id)
        return { statusCode: 400, body: JSON.stringify({ error: "words_id required" }) };

      await ddbDocClient.send(new PutCommand({ TableName: table, Item: item }));
      return { statusCode: 200, body: JSON.stringify({ message: `Item updated in ${table}`, item }) };
    }

    // =============== DELETE ===============
    if (method === "DELETE") {
      if (!users_id) return { statusCode: 400, body: JSON.stringify({ error: "users_id required" }) };

      let key = { users_id };

      if (table === "chat_logs") {
        if (!body.chatbot_logs_id)
          return { statusCode: 400, body: JSON.stringify({ error: "chatbot_logs_id required" }) };
        key.chatbot_logs_id = body.chatbot_logs_id;
      }

      if (table === "words") {
        if (!body.words_id)
          return { statusCode: 400, body: JSON.stringify({ error: "words_id required" }) };
        key.words_id = body.words_id;
      }

      await ddbDocClient.send(new DeleteCommand({ TableName: table, Key: key }));
      return { statusCode: 200, body: JSON.stringify({ message: `Item deleted from ${table}`, key }) };
    }

    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  } catch (err) {
    console.error("Error:", err);
    return { statusCode: 500, body: JSON.stringify({ error: "Internal Server Error" }) };
  }
};
