/**
 * 暂存仓库微服务主服务器
 * 提供用户偏好、用户统计、聊天历史、单词学习和用户资料的临时存储服务
 */

const express = require('express');
const cors = require('cors');
const routes = require('./routes');

const app = express();
const PORT = process.env.PORT || 3005;

// ==================== 中间件配置 ====================

// CORS 配置
app.use(cors({
    origin: ['http://localhost:3000', 'http://localhost:8080', 'http://127.0.0.1:5500'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// JSON 解析中间件
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// 请求日志中间件
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path} - ${req.ip}`);
    next();
});

// ==================== 路由配置 ====================

// API 路由
app.use('/api', routes);

// 根路径响应
app.get('/', (req, res) => {
    res.json({
        name: 'Storage Microservice',
        version: '1.0.0',
        description: '暂存仓库微服务，用于减少SQL I/O开销',
        endpoints: {
            userPreferences: '/api/user-preferences',
            userStatistics: '/api/user-statistics',
            chatHistories: '/api/chat-histories',
            words: '/api/words',
            health: '/api/health',
            stats: '/api/stats'
        },
        status: 'running',
        timestamp: new Date().toISOString()
    });
});

// ==================== 错误处理中间件 ====================

// 404 处理
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        error: 'Endpoint not found',
        path: req.originalUrl,
        method: req.method
    });
});

// 全局错误处理
app.use((error, req, res, next) => {
    console.error('Global error handler:', error);
    
    // 根据错误类型返回不同的状态码
    let statusCode = 500;
    let message = 'Internal server error';

    if (error.name === 'ValidationError') {
        statusCode = 400;
        message = error.message;
    } else if (error.name === 'CastError') {
        statusCode = 400;
        message = 'Invalid data format';
    } else if (error.message.includes('not found')) {
        statusCode = 404;
        message = error.message;
    }

    res.status(statusCode).json({
        success: false,
        error: message,
        timestamp: new Date().toISOString(),
        ...(process.env.NODE_ENV === 'development' && { stack: error.stack })
    });
});

// ==================== 服务器启动 ====================

// 优雅关闭处理
const server = app.listen(PORT, () => {
    console.log('='.repeat(50));
    console.log('🚀 Storage Microservice Started');
    console.log('='.repeat(50));
    console.log(`📍 Server running on port ${PORT}`);
    console.log(`🌐 API Base URL: http://localhost:${PORT}/api`);
    console.log(`📊 Health Check: http://localhost:${PORT}/api/health`);
    console.log(`📈 Statistics: http://localhost:${PORT}/api/stats`);
    console.log('='.repeat(50));
    console.log('Available Endpoints:');
    console.log('📝 User Preferences: /api/user-preferences');
    console.log('📊 User Statistics: /api/user-statistics');
    console.log('💬 Chat Histories: /api/chat-histories');
    console.log('📚 Words Learning: /api/words');
    console.log('🆔 User Profile: /api/profile');
    console.log('='.repeat(50));
});

// 优雅关闭处理
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully...');
    server.close(() => {
        console.log('Server closed.');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('\nSIGINT received, shutting down gracefully...');
    server.close(() => {
        console.log('Server closed.');
        process.exit(0);
    });
});

// 未捕获异常处理
process.on('uncaughtException', (error) => {
    console.error('Uncaught Exception:', error);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});

module.exports = app;