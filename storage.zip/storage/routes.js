/**
 * API 路由定义
 * 处理用户偏好、用户统计和聊天历史的RESTful API
 */

const express = require('express');
const storageEngine = require('./storage');

const router = express.Router();

// ==================== 用户偏好 API ====================

/**
 * GET /api/user-preferences/:userId - 获取用户偏好
 */
router.get('/user-preferences/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const preference = storageEngine.getUserPreference(userId);
        res.json({
            success: true,
            data: preference
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/user-preferences - 创建用户偏好
 */
router.post('/user-preferences', (req, res) => {
    try {
        const preference = storageEngine.setUserPreference(req.body);
        res.status(201).json({
            success: true,
            data: preference
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * PUT /api/user-preferences/:userId - 更新用户偏好
 */
router.put('/user-preferences/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const updateData = { ...req.body, users_id: userId };
        const preference = storageEngine.setUserPreference(updateData);
        res.json({
            success: true,
            data: preference
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/user-preferences/:userId - 删除用户偏好
 */
router.delete('/user-preferences/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        storageEngine.deleteUserPreference(userId);
        res.json({
            success: true,
            message: 'User preference deleted successfully'
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/user-preferences - 获取所有用户偏好
 */
router.get('/user-preferences', (req, res) => {
    try {
        const preferences = storageEngine.getAllUserPreferences();
        res.json({
            success: true,
            data: preferences,
            count: preferences.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ==================== 用户统计 API ====================

/**
 * GET /api/user-statistics/:userId - 获取用户统计
 */
router.get('/user-statistics/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const statistic = storageEngine.getUserStatistic(userId);
        res.json({
            success: true,
            data: statistic
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/user-statistics - 创建用户统计
 */
router.post('/user-statistics', (req, res) => {
    try {
        const statistic = storageEngine.setUserStatistic(req.body);
        res.status(201).json({
            success: true,
            data: statistic
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * PUT /api/user-statistics/:userId - 更新用户统计
 */
router.put('/user-statistics/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const updateData = { ...req.body, users_id: userId };
        const statistic = storageEngine.setUserStatistic(updateData);
        res.json({
            success: true,
            data: statistic
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/user-statistics/:userId - 删除用户统计
 */
router.delete('/user-statistics/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        storageEngine.deleteUserStatistic(userId);
        res.json({
            success: true,
            message: 'User statistic deleted successfully'
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/user-statistics - 获取所有用户统计
 */
router.get('/user-statistics', (req, res) => {
    try {
        const statistics = storageEngine.getAllUserStatistics();
        res.json({
            success: true,
            data: statistics,
            count: statistics.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ==================== 聊天历史 API ====================

/**
 * GET /api/chat-histories/:userId - 获取用户聊天历史
 */
router.get('/chat-histories/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const history = storageEngine.getChatHistory(userId);
        res.json({
            success: true,
            data: history,
            count: history.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/chat-histories - 添加聊天消息
 */
router.post('/chat-histories', (req, res) => {
    try {
        const message = storageEngine.addChatMessage(req.body);
        res.status(201).json({
            success: true,
            data: message
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/chat-histories/message/:messageId - 获取特定聊天消息
 */
router.get('/chat-histories/message/:messageId', (req, res) => {
    try {
        const { messageId } = req.params;
        const message = storageEngine.getChatMessage(messageId);
        res.json({
            success: true,
            data: message
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/chat-histories/message/:messageId - 删除聊天消息
 */
router.delete('/chat-histories/message/:messageId', (req, res) => {
    try {
        const { messageId } = req.params;
        storageEngine.deleteChatMessage(messageId);
        res.json({
            success: true,
            message: 'Chat message deleted successfully'
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/chat-histories/:userId - 清空用户聊天历史
 */
router.delete('/chat-histories/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        storageEngine.clearChatHistory(userId);
        res.json({
            success: true,
            message: 'Chat history cleared successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ==================== 单词学习 API ====================

/**
 * GET /api/words/:userId - 获取用户的学习单词列表
 */
router.get('/words/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        const words = storageEngine.getUserWords(userId);
        res.json({
            success: true,
            data: words,
            count: words.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/words - 添加学习单词
 */
router.post('/words', (req, res) => {
    try {
        const word = storageEngine.addWord(req.body);
        res.status(201).json({
            success: true,
            data: word
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/word/:wordId - 根据ID获取单词
 */
router.get('/word/:wordId', (req, res) => {
    try {
        const { wordId } = req.params;
        const word = storageEngine.getWord(wordId);
        res.json({
            success: true,
            data: word
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * PUT /api/word/:wordId - 更新学习单词
 */
router.put('/word/:wordId', (req, res) => {
    try {
        const { wordId } = req.params;
        const word = storageEngine.updateWord(wordId, req.body);
        res.json({
            success: true,
            data: word
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/word/:wordId - 删除学习单词
 */
router.delete('/word/:wordId', (req, res) => {
    try {
        const { wordId } = req.params;
        storageEngine.deleteWord(wordId);
        res.json({
            success: true,
            message: 'Word deleted successfully'
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/words/:userId - 清空用户的学习单词
 */
router.delete('/words/:userId', (req, res) => {
    try {
        const { userId } = req.params;
        storageEngine.clearUserWords(userId);
        res.json({
            success: true,
            message: 'User words cleared successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/words - 获取所有学习单词
 */
router.get('/words', (req, res) => {
    try {
        const words = storageEngine.getAllWords();
        res.json({
            success: true,
            data: words,
            count: words.length
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ==================== 系统状态 API ====================

/**
 * GET /api/stats - 获取系统统计信息
 */
router.get('/stats', (req, res) => {
    try {
        const stats = storageEngine.getStats();
        res.json({
            success: true,
            data: stats
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/clear-all - 清空所有数据
 */
router.post('/clear-all', (req, res) => {
    try {
        storageEngine.clearAll();
        res.json({
            success: true,
            message: 'All data cleared successfully'
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
});

// ==================== 用户资料 API (单用户模式) ====================

/**
 * GET /api/profile - 获取用户资料
 */
router.get('/profile', (req, res) => {
    try {
        const profile = storageEngine.getUserProfile();
        res.json({
            success: true,
            data: profile.toSafeObject()
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * POST /api/profile - 设置用户资料
 */
router.post('/profile', (req, res) => {
    try {
        const profile = storageEngine.setUserProfile(req.body);
        res.status(201).json({
            success: true,
            data: profile.toSafeObject()
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * PUT /api/profile - 更新用户资料
 */
router.put('/profile', (req, res) => {
    try {
        // 获取现有资料
        const existingProfile = storageEngine.getUserProfile();
        
        // 合并更新数据
        const updateData = {
            id: existingProfile.id,
            email: req.body.email || existingProfile.email,
            password_hash: req.body.password_hash || existingProfile.password_hash,
            username: req.body.username || existingProfile.username
        };
        
        const profile = storageEngine.setUserProfile(updateData);
        res.json({
            success: true,
            data: profile.toSafeObject()
        });
    } catch (error) {
        res.status(400).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * DELETE /api/profile - 删除用户资料
 */
router.delete('/profile', (req, res) => {
    try {
        storageEngine.deleteUserProfile();
        res.json({
            success: true,
            message: 'User profile deleted successfully'
        });
    } catch (error) {
        res.status(404).json({
            success: false,
            error: error.message
        });
    }
});

/**
 * GET /api/health - 健康检查
 */
router.get('/health', (req, res) => {
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString()
    });
});

module.exports = router;