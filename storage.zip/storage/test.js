/**
 * 存储微服务测试文件
 * 测试所有API端点的功能
 */

const http = require('http');
const querystring = require('querystring');

const BASE_URL = 'http://localhost:3005';
let testCount = 0;
let passCount = 0;

// 测试工具函数
function makeRequest(options, data = null) {
    return new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    const response = JSON.parse(body);
                    resolve({ statusCode: res.statusCode, data: response });
                } catch (error) {
                    resolve({ statusCode: res.statusCode, data: body });
                }
            });
        });

        req.on('error', reject);

        if (data) {
            req.write(JSON.stringify(data));
        }

        req.end();
    });
}

function assert(condition, message) {
    testCount++;
    if (condition) {
        console.log(`✅ PASS: ${message}`);
        passCount++;
    } else {
        console.log(`❌ FAIL: ${message}`);
    }
}

async function runTests() {
    console.log('='.repeat(60));
    console.log('🧪 开始测试存储微服务');
    console.log('='.repeat(60));

    try {
        // 清理所有数据
        console.log('\n🧹 清理测试数据...');
        const clearAll = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/clear-all',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        });
        assert(clearAll.statusCode === 200, '清理所有数据成功');

        // 测试健康检查
        console.log('\n📊 测试健康检查...');
        const healthCheck = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/health',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        assert(healthCheck.statusCode === 200, '健康检查返回200状态码');
        assert(healthCheck.data.success === true, '健康检查返回成功状态');

        // 测试用户偏好 API
        console.log('\n👤 测试用户偏好 API...');
        
        // 创建用户偏好
        const userPrefData = {
            users_id: 'test_user_001',
            age: 25,
            country: 'China',
            interest1: 'Technology',
            interest2: 'Music',
            level: 'Intermediate',
            native_language: 'Chinese',
            target_language: 'English'
        };

        const createPref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, userPrefData);

        assert(createPref.statusCode === 201, '创建用户偏好返回201状态码');
        assert(createPref.data.success === true, '创建用户偏好成功');
        assert(createPref.data.data.age === 25, '年龄字段正确转换为数字');

        // 获取用户偏好
        const getPref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences/test_user_001',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(getPref.statusCode === 200, '获取用户偏好返回200状态码');
        assert(getPref.data.data.users_id === 'test_user_001', '获取到正确的用户偏好');

        // 更新用户偏好
        const updatePref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences/test_user_001',
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        }, { ...userPrefData, age: 26 });

        assert(updatePref.statusCode === 200, '更新用户偏好返回200状态码');
        assert(updatePref.data.data.age === 26, '用户偏好更新成功');

        // 测试用户统计 API
        console.log('\n📈 测试用户统计 API...');
        
        const userStatData = {
            users_id: 'test_user_001',
            accuracy: 85,
            intonation: 78,
            words_learned: 150
        };

        const createStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, userStatData);

        assert(createStat.statusCode === 201, '创建用户统计返回201状态码');
        assert(createStat.data.data.accuracy === 85, '准确率字段正确');
        assert(createStat.data.data.timestamp, '自动生成时间戳');

        // 获取用户统计
        const getStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics/test_user_001',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(getStat.statusCode === 200, '获取用户统计返回200状态码');
        assert(getStat.data.data.words_learned === 150, '获取到正确的用户统计');

        // 测试聊天历史 API
        console.log('\n💬 测试聊天历史 API...');
        
        const chatMessage1 = {
            users_id: 'test_user_001',
            sender: 'user',
            message: {
                type: 'text',
                content: 'Hello, this is a test message',
                audio_path: '/audio/test1.wav'
            }
        };

        const addMsg1 = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/chat-histories',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, chatMessage1);

        assert(addMsg1.statusCode === 201, '添加聊天消息返回201状态码');
        assert(addMsg1.data.data.sender === 'user', '聊天消息发送者正确');
        assert(addMsg1.data.data.chatbot_logs_id, '自动生成消息ID');

        const messageId1 = addMsg1.data.data.chatbot_logs_id;

        // 等待1毫秒确保时间戳不同
        await new Promise(resolve => setTimeout(resolve, 1));

        // 添加第二条消息
        const chatMessage2 = {
            users_id: 'test_user_001',
            sender: 'assistant',
            message: {
                type: 'text',
                content: 'Hello! How can I help you today?',
                audio_path: '/audio/assistant1.wav'
            }
        };

        const addMsg2 = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/chat-histories',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, chatMessage2);

        assert(addMsg2.statusCode === 201, '添加第二条聊天消息成功');

        // 获取聊天历史
        const getChatHistory = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/chat-histories/test_user_001',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(getChatHistory.statusCode === 200, '获取聊天历史返回200状态码');
        assert(getChatHistory.data.count === 2, '聊天历史包含2条消息');
        assert(getChatHistory.data.data[0].sender === 'user', '消息顺序正确');

        // 获取特定消息
        const getSpecificMsg = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: `/api/chat-histories/message/${messageId1}`,
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(getSpecificMsg.statusCode === 200, '获取特定消息返回200状态码');
        assert(getSpecificMsg.data.data.chatbot_logs_id === messageId1, '获取到正确的消息');

        // 测试系统统计
        console.log('\n📊 测试系统统计...');
        
        const getStats = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/stats',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(getStats.statusCode === 200, '获取系统统计返回200状态码');
        assert(getStats.data.data.userPreferences >= 1, '用户偏好计数正确');
        assert(getStats.data.data.userStatistics >= 1, '用户统计计数正确');
        assert(getStats.data.data.totalChatMessages >= 2, '聊天消息计数正确');

        // 测试数据验证
        console.log('\n🔍 测试数据验证...');
        
        // 测试无效年龄
        const invalidAge = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { ...userPrefData, users_id: 'invalid_user', age: -1 });

        assert(invalidAge.statusCode === 400, '无效年龄返回400状态码');

        // 测试缺失必填字段
        const missingField = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, { users_id: 'incomplete_user', age: 25 });

        assert(missingField.statusCode === 400, '缺失必填字段返回400状态码');

        // 测试无效发送者
        const invalidSender = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/chat-histories',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, {
            users_id: 'test_user_001',
            sender: 'invalid_sender',
            message: { type: 'text', content: 'test' }
        });

        assert(invalidSender.statusCode === 400, '无效发送者返回400状态码');

        // 测试删除操作
        console.log('\n🗑️ 测试删除操作...');
        
        // 删除聊天消息
        const deleteMsg = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: `/api/chat-histories/message/${messageId1}`,
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(deleteMsg.statusCode === 200, '删除聊天消息成功');

        // 删除用户偏好
        const deletePref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences/test_user_001',
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(deletePref.statusCode === 200, '删除用户偏好成功');

        // 删除用户统计
        const deleteStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics/test_user_001',
            method: 'DELETE',
            headers: { 'Content-Type': 'application/json' }
        });

        assert(deleteStat.statusCode === 200, '删除用户统计成功');

        console.log('\n' + '='.repeat(60));
        console.log(`🎉 测试完成！通过 ${passCount}/${testCount} 项测试`);
        
        if (passCount === testCount) {
            console.log('✅ 所有测试通过！存储微服务工作正常。');
        } else {
            console.log(`❌ ${testCount - passCount} 项测试失败。`);
        }
        console.log('='.repeat(60));

    } catch (error) {
        console.error('❌ 测试过程中出现错误:', error.message);
    }
}

// 检查服务器是否运行
async function checkServer() {
    try {
        await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/health',
            method: 'GET'
        });
        return true;
    } catch (error) {
        return false;
    }
}

// 主函数
async function main() {
    console.log('检查服务器状态...');
    const isServerRunning = await checkServer();
    
    if (!isServerRunning) {
        console.log('❌ 服务器未运行，请先启动服务器：npm start');
        process.exit(1);
    }

    console.log('✅ 服务器正在运行，开始测试...');
    await runTests();
}

// 如果直接运行此文件，则执行测试
if (require.main === module) {
    main();
}

module.exports = { runTests, makeRequest };