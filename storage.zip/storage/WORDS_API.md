# Words API Documentation

## 概述
Words API 提供了完整的单词学习存储功能，允许用户存储、管理和检索学习的单词对（母语单词和目标语言单词）。

## 数据结构

### Word 对象
```javascript
{
    "id": "uuid-string",          // 单词记录的唯一ID
    "user_id": "string",          // 用户ID
    "native_word": "string",      // 母语单词
    "target_word": "string",      // 目标语言单词
    "timestamp": "2024-12-19T10:30:00.000Z"  // 创建/更新时间戳
}
```

## API 端点

### 1. 添加学习单词
**POST** `/api/words`

**请求体:**
```javascript
{
    "user_id": "user123",
    "native_word": "苹果",
    "target_word": "apple"
}
```

**响应:**
```javascript
{
    "success": true,
    "data": {
        "id": "generated-uuid",
        "user_id": "user123",
        "native_word": "苹果", 
        "target_word": "apple",
        "timestamp": "2024-12-19T10:30:00.000Z"
    }
}
```

### 2. 获取用户的学习单词列表
**GET** `/api/words/:userId`

**响应:**
```javascript
{
    "success": true,
    "data": [
        {
            "id": "word-id-1",
            "user_id": "user123",
            "native_word": "苹果",
            "target_word": "apple",
            "timestamp": "2024-12-19T10:30:00.000Z"
        }
    ],
    "count": 1
}
```

### 3. 根据ID获取单词
**GET** `/api/word/:wordId`

**响应:**
```javascript
{
    "success": true,
    "data": {
        "id": "word-id-1",
        "user_id": "user123", 
        "native_word": "苹果",
        "target_word": "apple",
        "timestamp": "2024-12-19T10:30:00.000Z"
    }
}
```

### 4. 更新学习单词
**PUT** `/api/word/:wordId`

**请求体:**
```javascript
{
    "native_word": "红苹果",    // 可选
    "target_word": "red apple", // 可选
    "timestamp": "custom-timestamp"  // 可选
}
```

**响应:**
```javascript
{
    "success": true,
    "data": {
        "id": "word-id-1",
        "user_id": "user123",
        "native_word": "红苹果",
        "target_word": "red apple", 
        "timestamp": "2024-12-19T10:35:00.000Z"
    }
}
```

### 5. 删除学习单词
**DELETE** `/api/word/:wordId`

**响应:**
```javascript
{
    "success": true,
    "message": "Word deleted successfully"
}
```

### 6. 清空用户的学习单词
**DELETE** `/api/words/:userId`

**响应:**
```javascript
{
    "success": true,
    "message": "User words cleared successfully"
}
```

### 7. 获取所有学习单词 (管理员功能)
**GET** `/api/words`

**响应:**
```javascript
{
    "success": true,
    "data": [
        {
            "id": "word-id-1",
            "user_id": "user123",
            "native_word": "苹果",
            "target_word": "apple",
            "timestamp": "2024-12-19T10:30:00.000Z"
        }
    ],
    "count": 1
}
```

## 错误处理

所有端点都会返回标准的错误响应格式:

```javascript
{
    "success": false,
    "error": "错误信息描述"
}
```

**常见错误状态码:**
- `400`: 请求数据无效或缺失必需字段
- `404`: 找不到指定的单词或用户
- `500`: 服务器内部错误

## 数据验证

创建或更新单词时，系统会验证以下字段:
- `user_id`: 必需，不能为空
- `native_word`: 必需，不能为空
- `target_word`: 必需，不能为空
- `timestamp`: 可选，默认为当前时间

## 使用示例

### JavaScript/Node.js 示例
```javascript
const axios = require('axios');
const BASE_URL = 'http://localhost:3005/api';

// 添加单词
const addWord = async () => {
    try {
        const response = await axios.post(`${BASE_URL}/words`, {
            user_id: 'user123',
            native_word: '你好',
            target_word: 'hello'
        });
        console.log('单词添加成功:', response.data);
    } catch (error) {
        console.error('添加失败:', error.response.data);
    }
};

// 获取用户单词
const getUserWords = async (userId) => {
    try {
        const response = await axios.get(`${BASE_URL}/words/${userId}`);
        console.log('用户单词列表:', response.data);
    } catch (error) {
        console.error('获取失败:', error.response.data);
    }
};
```

### cURL 示例
```bash
# 添加单词
curl -X POST http://localhost:3005/api/words \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user123",
    "native_word": "谢谢",
    "target_word": "thank you"
  }'

# 获取用户单词列表
curl -X GET http://localhost:3005/api/words/user123

# 更新单词
curl -X PUT http://localhost:3005/api/word/word-id-here \
  -H "Content-Type: application/json" \
  -d '{
    "target_word": "thanks"
  }'
```

## 注意事项

1. **时间戳格式**: 使用 ISO 8601 格式 (YYYY-MM-DDTHH:mm:ss.sssZ)
2. **用户单词排序**: 获取用户单词列表时，默认按创建时间降序排列（最新的在前）
3. **数据持久性**: 当前实现使用内存存储，服务器重启后数据会丢失
4. **并发安全**: 内存存储实现是线程安全的
5. **ID生成**: 单词ID使用UUID v4自动生成