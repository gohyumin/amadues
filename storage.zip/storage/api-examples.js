/**
 * 存储微服务 API 使用示例
 * 展示如何使用各种API端点
 */

const http = require('http');

const BASE_URL = 'http://localhost:3005';

// HTTP请求工具函数
function makeRequest(options, data = null) {
    return new Promise((resolve, reject) => {
        const req = http.request(options, (res) => {
            let body = '';
            res.on('data', chunk => body += chunk);
            res.on('end', () => {
                try {
                    const response = JSON.parse(body);
                    resolve({ statusCode: res.statusCode, data: response });
                } catch (error) {
                    resolve({ statusCode: res.statusCode, data: body });
                }
            });
        });

        req.on('error', reject);

        if (data) {
            req.write(JSON.stringify(data));
        }

        req.end();
    });
}

async function demonstrateAPI() {
    console.log('🚀 存储微服务 API 使用示例');
    console.log('='.repeat(50));
    console.log('📍 服务地址: http://localhost:3005');
    console.log('='.repeat(50));

    try {
        // 1. 健康检查
        console.log('\n📊 1. 健康检查');
        const health = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/health',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('✅ 健康状态:', health.data);

        // 2. 创建用户偏好
        console.log('\n👤 2. 创建用户偏好');
        const userPreference = {
            user_id: 'demo_user_123',
            age: 28,
            country: 'China',
            interest1: 'Programming',
            interest2: 'Gaming',
            level: 'Advanced',
            native_language: 'Chinese',
            target_language: 'English'
        };

        const createPref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, userPreference);
        console.log('✅ 创建用户偏好:', createPref.data);

        // 3. 获取用户偏好
        console.log('\n📖 3. 获取用户偏好');
        const getPref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences/demo_user_123',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('✅ 用户偏好:', getPref.data.data);

        // 4. 更新用户偏好
        console.log('\n🔄 4. 更新用户偏好');
        const updatePref = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences/demo_user_123',
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        }, { ...userPreference, age: 29, level: 'Expert' });
        console.log('✅ 更新后用户偏好:', updatePref.data.data);

        // 5. 创建用户统计
        console.log('\n📈 5. 创建用户统计');
        const userStatistic = {
            user_id: 'demo_user_123',
            accuracy: 92,
            intonation: 87,
            words_learned: 345
        };

        const createStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
        }, userStatistic);
        console.log('✅ 创建用户统计:', createStat.data.data);

        // 6. 获取用户统计
        console.log('\n📊 6. 获取用户统计');
        const getStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics/demo_user_123',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('✅ 用户统计:', getStat.data.data);

        // 7. 添加聊天消息
        console.log('\n💬 7. 添加聊天消息');
        const messages = [
            {
                user_id: 'demo_user_123',
                sender: 'user',
                message: {
                    type: 'text',
                    content: 'Hello, I want to practice English pronunciation.',
                    audio_path: '/uploads/user_audio_001.wav'
                }
            },
            {
                user_id: 'demo_user_123',
                sender: 'assistant',
                message: {
                    type: 'text',
                    content: 'Great! Let\'s start with some basic words. Can you say "pronunciation"?',
                    audio_path: '/uploads/assistant_audio_001.wav'
                }
            },
            {
                user_id: 'demo_user_123',
                sender: 'user',
                message: {
                    type: 'text',
                    content: 'Pronunciation',
                    audio_path: '/uploads/user_audio_002.wav'
                }
            }
        ];

        const messageIds = [];
        for (const [index, message] of messages.entries()) {
            const addMsg = await makeRequest({
                hostname: 'localhost',
                port: 3005,
                path: '/api/chat-histories',
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            }, message);
            console.log(`✅ 添加消息 ${index + 1} (${message.sender}): ${addMsg.data.data.id}`);
            messageIds.push(addMsg.data.data.id);
            // 短暂延迟确保时间戳不同
            await new Promise(resolve => setTimeout(resolve, 10));
        }

        // 8. 获取聊天历史
        console.log('\n📜 8. 获取聊天历史');
        const getChatHistory = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/chat-histories/demo_user_123',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log(`✅ 聊天历史条数: ${getChatHistory.data.count}`);
        getChatHistory.data.data.forEach((msg, index) => {
            const time = new Date(msg.timestamp).toLocaleTimeString();
            console.log(`   ${index + 1}. [${time}] ${msg.sender}: ${msg.message.content}`);
        });

        // 9. 获取特定消息
        console.log('\n🔍 9. 获取特定消息');
        if (messageIds.length > 0) {
            const getSpecificMsg = await makeRequest({
                hostname: 'localhost',
                port: 3005,
                path: `/api/chat-histories/message/${messageIds[0]}`,
                method: 'GET',
                headers: { 'Content-Type': 'application/json' }
            });
            console.log('✅ 特定消息:', {
                id: getSpecificMsg.data.data.id,
                sender: getSpecificMsg.data.data.sender,
                content: getSpecificMsg.data.data.message.content
            });
        }

        // 10. 系统统计
        console.log('\n📊 10. 系统统计');
        const getStats = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/stats',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log('✅ 系统统计:', getStats.data.data);

        // 11. 更新用户统计
        console.log('\n🔄 11. 更新用户统计');
        const updateStat = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics/demo_user_123',
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' }
        }, {
            ...userStatistic,
            accuracy: 95,
            words_learned: 350
        });
        console.log('✅ 更新后用户统计:', {
            accuracy: updateStat.data.data.accuracy,
            intonation: updateStat.data.data.intonation,
            words_learned: updateStat.data.data.words_learned
        });

        // 12. 获取所有数据
        console.log('\n📋 12. 获取所有数据');
        
        const getAllPrefs = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-preferences',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log(`✅ 所有用户偏好数量: ${getAllPrefs.data.count}`);

        const getAllStats = await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/user-statistics',
            method: 'GET',
            headers: { 'Content-Type': 'application/json' }
        });
        console.log(`✅ 所有用户统计数量: ${getAllStats.data.count}`);

        console.log('\n' + '='.repeat(50));
        console.log('✅ API示例演示完成！');
        console.log('='.repeat(50));
        
        console.log('\n📝 常用API端点总结:');
        console.log('┌─────────────────────────────────────────────┐');
        console.log('│ 🏥 健康检查: GET /api/health                  │');
        console.log('│ 👤 用户偏好: /api/user-preferences           │');
        console.log('│    - GET    获取用户偏好                     │');
        console.log('│    - POST   创建用户偏好                     │');
        console.log('│    - PUT    更新用户偏好                     │');
        console.log('│    - DELETE 删除用户偏好                     │');
        console.log('│ 📊 用户统计: /api/user-statistics            │');
        console.log('│    - GET    获取用户统计                     │');
        console.log('│    - POST   创建用户统计                     │');
        console.log('│    - PUT    更新用户统计                     │');
        console.log('│    - DELETE 删除用户统计                     │');
        console.log('│ 💬 聊天历史: /api/chat-histories             │');
        console.log('│    - GET    获取聊天历史                     │');
        console.log('│    - POST   添加聊天消息                     │');
        console.log('│    - DELETE 删除聊天消息                     │');
        console.log('│ 📈 系统统计: GET /api/stats                  │');
        console.log('│ 🗑️  清空数据: POST /api/clear-all            │');
        console.log('└─────────────────────────────────────────────┘');

    } catch (error) {
        console.error('❌ API演示过程中出现错误:', error.message);
        if (error.code === 'ECONNREFUSED') {
            console.log('💡 请确保存储微服务已启动: npm start');
        }
    }
}

// 检查服务器是否运行
async function checkServer() {
    try {
        await makeRequest({
            hostname: 'localhost',
            port: 3005,
            path: '/api/health',
            method: 'GET'
        });
        return true;
    } catch (error) {
        return false;
    }
}

// 主函数
async function main() {
    console.log('🔍 检查服务器状态...');
    const isServerRunning = await checkServer();
    
    if (!isServerRunning) {
        console.log('❌ 存储微服务未运行');
        console.log('💡 请先启动服务器:');
        console.log('   cd storage && npm start');
        console.log('   或者: cd storage && npm run dev');
        process.exit(1);
    }

    console.log('✅ 服务器正在运行，开始API演示...');
    await demonstrateAPI();
}

// 如果直接运行此文件，则执行示例
if (require.main === module) {
    main();
}

module.exports = { demonstrateAPI, makeRequest, checkServer };