/**
 * Words API 测试示例
 * 演示如何使用新的单词学习存储功能
 */

const axios = require('axios');

// 服务器地址
const BASE_URL = 'http://localhost:3005/api';

async function testWordsAPI() {
    try {
        console.log('🧪 Testing Words API...\n');

        // 1. 添加学习单词
        console.log('1. 添加学习单词:');
        const word1 = await axios.post(`${BASE_URL}/words`, {
            user_id: 'user123',
            native_word: '苹果',
            target_word: 'apple'
        });
        console.log('✅ 添加成功:', word1.data);

        const word2 = await axios.post(`${BASE_URL}/words`, {
            user_id: 'user123',
            native_word: '书',
            target_word: 'book'
        });
        console.log('✅ 添加成功:', word2.data);

        // 2. 获取用户的学习单词列表
        console.log('\n2. 获取用户学习单词列表:');
        const userWords = await axios.get(`${BASE_URL}/words/user123`);
        console.log('✅ 获取成功:', userWords.data);

        // 3. 根据ID获取单词
        console.log('\n3. 根据ID获取单词:');
        const wordId = word1.data.data.id;
        const singleWord = await axios.get(`${BASE_URL}/word/${wordId}`);
        console.log('✅ 获取成功:', singleWord.data);

        // 4. 更新学习单词
        console.log('\n4. 更新学习单词:');
        const updatedWord = await axios.put(`${BASE_URL}/word/${wordId}`, {
            target_word: 'red apple'  // 更新目标语言单词
        });
        console.log('✅ 更新成功:', updatedWord.data);

        // 5. 获取所有学习单词
        console.log('\n5. 获取所有学习单词:');
        const allWords = await axios.get(`${BASE_URL}/words`);
        console.log('✅ 获取成功:', allWords.data);

        // 6. 删除单词
        console.log('\n6. 删除学习单词:');
        await axios.delete(`${BASE_URL}/word/${word2.data.data.id}`);
        console.log('✅ 删除成功');

        // 7. 验证删除结果
        console.log('\n7. 验证删除后的用户单词列表:');
        const finalUserWords = await axios.get(`${BASE_URL}/words/user123`);
        console.log('✅ 验证成功:', finalUserWords.data);

        console.log('\n🎉 所有测试通过！');

    } catch (error) {
        console.error('❌ 测试失败:', error.response?.data || error.message);
    }
}

// 如果直接运行此文件，则执行测试
if (require.main === module) {
    testWordsAPI();
}

module.exports = { testWordsAPI };