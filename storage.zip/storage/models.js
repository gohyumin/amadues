/**
 * 数据模型定义
 */

/**
 * 用户偏好数据结构
 * @typedef {Object} UserPreference
 * @property {string} users_id - 用户ID
 * @property {number} age - 年龄 (整数)
 * @property {string} country - 国家
 * @property {string} interest1 - 兴趣1
 * @property {string} interest2 - 兴趣2
 * @property {string} level - 等级
 * @property {string} native_language - 母语
 * @property {string} target_language - 目标语言
 */
class UserPreference {
    constructor(users_id, age, country, interest1, interest2, level, native_language, target_language) {
        this.users_id = users_id ? String(users_id) : '';
        this.age = parseInt(age) || 0;
        this.country = country ? String(country) : '';
        this.interest1 = interest1 ? String(interest1) : '';
        this.interest2 = interest2 ? String(interest2) : '';
        this.level = level ? String(level) : '';
        this.native_language = native_language ? String(native_language) : '';
        this.target_language = target_language ? String(target_language) : '';
    }

    // 验证数据完整性
    validate() {
        if (!this.users_id || this.users_id.trim() === '') throw new Error('users_id is required');
        if (isNaN(this.age) || this.age < 0) throw new Error('age must be a positive integer');
        if (!this.country || this.country.trim() === '') throw new Error('country is required');
        if (!this.interest1 || this.interest1.trim() === '') throw new Error('interest1 is required');
        if (!this.interest2 || this.interest2.trim() === '') throw new Error('interest2 is required');
        if (!this.level || this.level.trim() === '') throw new Error('level is required');
        if (!this.native_language || this.native_language.trim() === '') throw new Error('native_language is required');
        if (!this.target_language || this.target_language.trim() === '') throw new Error('target_language is required');
        return true;
    }
}

/**
 * 用户统计数据结构
 * @typedef {Object} UserStatistic
 * @property {string} users_id - 用户ID
 * @property {number} accuracy - 准确率 (整数)
 * @property {number} intonation - 语调分数 (整数)
 * @property {number} words_learned - 已学词汇数 (整数)
 * @property {string} timestamp - 时间戳
 */
class UserStatistic {
    constructor(users_id, accuracy, intonation, words_learned, timestamp = null) {
        this.users_id = String(users_id);
        this.accuracy = parseInt(accuracy);
        this.intonation = parseInt(intonation);
        this.words_learned = parseInt(words_learned);
        this.timestamp = timestamp || new Date().toISOString();
    }

    // 验证数据完整性
    validate() {
        if (!this.users_id) throw new Error('users_id is required');
        if (isNaN(this.accuracy) || this.accuracy < 0) throw new Error('accuracy must be a non-negative integer');
        if (isNaN(this.intonation) || this.intonation < 0) throw new Error('intonation must be a non-negative integer');
        if (isNaN(this.words_learned) || this.words_learned < 0) throw new Error('words_learned must be a non-negative integer');
        if (!this.timestamp) throw new Error('timestamp is required');
        return true;
    }
}

/**
 * 聊天历史消息结构
 * @typedef {Object} ChatMessage
 * @property {string} id - 消息ID
 * @property {string} users_id - 用户ID
 * @property {string} sender - 发送者 ("user" 或 "assistant")
 * @property {string} timestamp - 时间戳
 * @property {Object} message - 消息内容
 * @property {string} message.type - 消息类型
/**
 * 聊天历史消息结构
 * @typedef {Object} ChatMessage
 * @property {string} chatbot_logs_id - 消息ID
 * @property {string} users_id - 用户ID
 * @property {string} sender - 发送者 ("user" 或 "assistant")
 * @property {string} timestamp - 时间戳
 * @property {Object} message - 消息内容
 * @property {string} message.type - 消息类型
 * @property {string} message.content - 消息内容
 * @property {string} message.audio_path - 音频路径
 */
class ChatMessage {
    constructor(chatbot_logs_id, users_id, sender, message, timestamp = null) {
        this.chatbot_logs_id = String(chatbot_logs_id);
        this.users_id = String(users_id);
        this.sender = String(sender);
        this.timestamp = timestamp || new Date().toISOString();
        this.message = {
            type: String(message.type || 'text'),
            content: String(message.content || ''),
            audio_path: String(message.audio_path || '')
        };
    }

    // 验证数据完整性
    validate() {
        if (!this.chatbot_logs_id) throw new Error('chatbot_logs_id is required');
        if (!this.users_id) throw new Error('users_id is required');
        if (!['user', 'assistant'].includes(this.sender)) {
            throw new Error('sender must be "user" or "assistant"');
        }
        if (!this.timestamp) throw new Error('timestamp is required');
        if (!this.message.type) throw new Error('message.type is required');
        return true;
    }
}

/**
 * 单词学习数据结构
 * @typedef {Object} Word
 * @property {string} words_id - 单词记录ID
 * @property {string} users_id - 用户ID
 * @property {string} native_word - 母语单词
 * @property {string} target_word - 目标语言单词
 * @property {string} timestamp - 时间戳
 */
class Word {
    constructor(words_id, users_id, native_word, target_word, timestamp = null) {
        this.words_id = words_id ? String(words_id) : require('uuid').v4();
        this.users_id = String(users_id);
        this.native_word = String(native_word);
        this.target_word = String(target_word);
        this.timestamp = timestamp || new Date().toISOString();
    }

    // 验证数据完整性
    validate() {
        if (!this.words_id) throw new Error('words_id is required');
        if (!this.users_id || this.users_id.trim() === '') throw new Error('users_id is required');
        if (!this.native_word || this.native_word.trim() === '') throw new Error('native_word is required');
        if (!this.target_word || this.target_word.trim() === '') throw new Error('target_word is required');
        if (!this.timestamp) throw new Error('timestamp is required');
        return true;
    }
}

/**
 * 用户个人资料数据结构 (单用户模式)
 * @typedef {Object} UserProfile
 * @property {string} id - 用户ID
 * @property {string} email - 用户邮箱
 * @property {string} password_hash - 密码哈希
 * @property {string} username - 用户名
 */
class UserProfile {
    constructor(id, email, password_hash, username) {
        this.id = id ? String(id) : require('uuid').v4();
        this.email = String(email || '').toLowerCase().trim();
        this.password_hash = String(password_hash || '');
        this.username = String(username || '').trim();
    }

    // 验证数据完整性
    validate() {
        if (!this.id || this.id.trim() === '') throw new Error('id is required');
        if (!this.email || this.email.trim() === '') throw new Error('email is required');
        if (!this.isValidEmail(this.email)) throw new Error('email format is invalid');
        if (!this.password_hash || this.password_hash.trim() === '') throw new Error('password_hash is required');
        if (!this.username || this.username.trim() === '') throw new Error('username is required');
        if (this.username.length < 2) throw new Error('username must be at least 2 characters');
        return true;
    }

    // 验证邮箱格式
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // 转换为安全对象（不包含密码哈希）
    toSafeObject() {
        const { password_hash, ...safeData } = this;
        return safeData;
    }
}

module.exports = {
    UserPreference,
    UserStatistic,
    ChatMessage,
    Word,
    UserProfile
};