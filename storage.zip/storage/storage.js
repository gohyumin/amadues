/**
 * 内存存储引擎
 * 管理用户偏好、用户统计和聊天历史数据
 */

const { UserPreference, UserStatistic, ChatMessage, Word, UserProfile } = require('./models');
const { v4: uuidv4 } = require('uuid');

class StorageEngine {
    constructor() {
        // 内存存储容器
        this.userPreferences = new Map(); // key: users_id, value: UserPreference
        this.userStatistics = new Map(); // key: users_id, value: UserStatistic
        this.chatHistories = new Map(); // key: users_id, value: ChatMessage[]
        this.chatMessages = new Map(); // key: chatbot_logs_id, value: ChatMessage
        this.words = new Map(); // key: words_id, value: Word
        this.userWords = new Map(); // key: users_id, value: Word[]
        this.userProfile = null; // 单个用户资料
    }

    // ==================== 用户偏好管理 ====================

    /**
     * 创建或更新用户偏好
     */
    setUserPreference(preferenceData) {
        try {
            const preference = new UserPreference(
                preferenceData.users_id,
                preferenceData.age,
                preferenceData.country,
                preferenceData.interest1,
                preferenceData.interest2,
                preferenceData.level,
                preferenceData.native_language,
                preferenceData.target_language
            );
            
            preference.validate();
            this.userPreferences.set(preference.users_id, preference);
            return preference;
        } catch (error) {
            throw new Error(`Failed to set user preference: ${error.message}`);
        }
    }

    /**
     * 获取用户偏好
     */
    getUserPreference(userId) {
        const preference = this.userPreferences.get(String(userId));
        if (!preference) {
            throw new Error(`User preference not found for users_id: ${userId}`);
        }
        return preference;
    }

    /**
     * 删除用户偏好
     */
    deleteUserPreference(userId) {
        const deleted = this.userPreferences.delete(String(userId));
        if (!deleted) {
            throw new Error(`User preference not found for users_id: ${userId}`);
        }
        return true;
    }

    /**
     * 获取所有用户偏好
     */
    getAllUserPreferences() {
        return Array.from(this.userPreferences.values());
    }

    // ==================== 用户统计管理 ====================

    /**
     * 创建或更新用户统计
     */
    setUserStatistic(statisticData) {
        try {
            const statistic = new UserStatistic(
                statisticData.users_id,
                statisticData.accuracy,
                statisticData.intonation,
                statisticData.words_learned,
                statisticData.timestamp
            );
            
            statistic.validate();
            this.userStatistics.set(statistic.users_id, statistic);
            return statistic;
        } catch (error) {
            throw new Error(`Failed to set user statistic: ${error.message}`);
        }
    }

    /**
     * 获取用户统计
     */
    getUserStatistic(userId) {
        const statistic = this.userStatistics.get(String(userId));
        if (!statistic) {
            throw new Error(`User statistic not found for users_id: ${userId}`);
        }
        return statistic;
    }

    /**
     * 删除用户统计
     */
    deleteUserStatistic(userId) {
        const deleted = this.userStatistics.delete(String(userId));
        if (!deleted) {
            throw new Error(`User statistic not found for users_id: ${userId}`);
        }
        return true;
    }

    /**
     * 获取所有用户统计
     */
    getAllUserStatistics() {
        return Array.from(this.userStatistics.values());
    }

    // ==================== 聊天历史管理 ====================

    /**
     * 添加聊天消息
     */
    addChatMessage(messageData) {
        try {
            const messageId = messageData.chatbot_logs_id || uuidv4();
            const message = new ChatMessage(
                messageId,
                messageData.users_id,
                messageData.sender,
                messageData.message,
                messageData.timestamp
            );

            message.validate();
            
            // 存储消息到消息映射表
            this.chatMessages.set(message.chatbot_logs_id, message);
            
            // 添加到用户聊天历史
            if (!this.chatHistories.has(message.users_id)) {
                this.chatHistories.set(message.users_id, []);
            }
            this.chatHistories.get(message.users_id).push(message);
            
            return message;
        } catch (error) {
            throw new Error(`Failed to add chat message: ${error.message}`);
        }
    }

    /**
     * 获取用户聊天历史
     */
    getChatHistory(userId) {
        const history = this.chatHistories.get(String(userId));
        if (!history) {
            return []; // 返回空数组而不是抛出错误
        }
        // 按时间戳排序，如果时间戳相同则按ID排序以保证顺序一致性
        return history.sort((a, b) => {
            const timeCompare = new Date(a.timestamp) - new Date(b.timestamp);
            return timeCompare !== 0 ? timeCompare : a.chatbot_logs_id.localeCompare(b.chatbot_logs_id);
        });
    }

    /**
     * 根据消息ID获取消息
     */
    getChatMessage(messageId) {
        const message = this.chatMessages.get(String(messageId));
        if (!message) {
            throw new Error(`Chat message not found for id: ${messageId}`);
        }
        return message;
    }

    /**
     * 删除聊天消息
     */
    deleteChatMessage(messageId) {
        const message = this.chatMessages.get(String(messageId));
        if (!message) {
            throw new Error(`Chat message not found for chatbot_logs_id: ${messageId}`);
        }

        // 从消息映射表中删除
        this.chatMessages.delete(String(messageId));

        // 从用户聊天历史中删除
        const userHistory = this.chatHistories.get(message.users_id);
        if (userHistory) {
            const index = userHistory.findIndex(msg => msg.chatbot_logs_id === message.chatbot_logs_id);
            if (index > -1) {
                userHistory.splice(index, 1);
            }
        }

        return true;
    }

    /**
     * 清空用户聊天历史
     */
    clearChatHistory(userId) {
        const history = this.chatHistories.get(String(userId));
        if (history) {
            // 从消息映射表中删除所有消息
            history.forEach(message => {
                this.chatMessages.delete(message.chatbot_logs_id);
            });
            // 清空用户历史
            this.chatHistories.set(String(userId), []);
        }
        return true;
    }

    // ==================== 单词学习管理 ====================

    /**
     * 添加学习单词
     */
    addWord(wordData) {
        try {
            const wordId = wordData.words_id || uuidv4();
            const word = new Word(
                wordId,
                wordData.users_id,
                wordData.native_word,
                wordData.target_word,
                wordData.timestamp
            );

            word.validate();
            
            // 存储单词到单词映射表
            this.words.set(word.words_id, word);
            
            // 添加到用户单词列表
            if (!this.userWords.has(word.users_id)) {
                this.userWords.set(word.users_id, []);
            }
            this.userWords.get(word.users_id).push(word);
            
            return word;
        } catch (error) {
            throw new Error(`Failed to add word: ${error.message}`);
        }
    }

    /**
     * 获取用户的学习单词列表
     */
    getUserWords(userId) {
        const words = this.userWords.get(String(userId));
        if (!words) {
            return []; // 返回空数组而不是抛出错误
        }
        // 按时间戳排序，最新的在前
        return words.sort((a, b) => {
            const timeCompare = new Date(b.timestamp) - new Date(a.timestamp);
            return timeCompare !== 0 ? timeCompare : b.words_id.localeCompare(a.words_id);
        });
    }

    /**
     * 根据单词ID获取单词
     */
    getWord(wordId) {
        const word = this.words.get(String(wordId));
        if (!word) {
            throw new Error(`Word not found for words_id: ${wordId}`);
        }
        return word;
    }

    /**
     * 更新学习单词
     */
    updateWord(wordId, updateData) {
        try {
            const existingWord = this.words.get(String(wordId));
            if (!existingWord) {
                throw new Error(`Word not found for words_id: ${wordId}`);
            }

            const updatedWord = new Word(
                existingWord.words_id,
                existingWord.users_id,
                updateData.native_word || existingWord.native_word,
                updateData.target_word || existingWord.target_word,
                updateData.timestamp || existingWord.timestamp
            );

            updatedWord.validate();
            
            // 更新单词映射表
            this.words.set(wordId, updatedWord);
            
            // 更新用户单词列表
            const userWords = this.userWords.get(existingWord.users_id);
            if (userWords) {
                const index = userWords.findIndex(word => word.words_id === wordId);
                if (index > -1) {
                    userWords[index] = updatedWord;
                }
            }
            
            return updatedWord;
        } catch (error) {
            throw new Error(`Failed to update word: ${error.message}`);
        }
    }

    /**
     * 删除学习单词
     */
    deleteWord(wordId) {
        const word = this.words.get(String(wordId));
        if (!word) {
            throw new Error(`Word not found for words_id: ${wordId}`);
        }

        // 从单词映射表中删除
        this.words.delete(String(wordId));

        // 从用户单词列表中删除
        const userWords = this.userWords.get(word.users_id);
        if (userWords) {
            const index = userWords.findIndex(w => w.words_id === word.words_id);
            if (index > -1) {
                userWords.splice(index, 1);
            }
        }

        return true;
    }

    /**
     * 清空用户的学习单词
     */
    clearUserWords(userId) {
        const words = this.userWords.get(String(userId));
        if (words) {
            // 从单词映射表中删除所有单词
            words.forEach(word => {
                this.words.delete(word.words_id);
            });
            // 清空用户单词列表
            this.userWords.set(String(userId), []);
        }
        return true;
    }

    /**
     * 获取所有学习单词
     */
    getAllWords() {
        return Array.from(this.words.values());
    }

    // ==================== 用户资料管理 (单用户模式) ====================

    /**
     * 设置用户资料
     */
    setUserProfile(profileData) {
        try {
            const profile = new UserProfile(
                profileData.id,
                profileData.email,
                profileData.password_hash,
                profileData.username
            );
            
            profile.validate();
            this.userProfile = profile;
            return profile;
        } catch (error) {
            throw new Error(`Failed to set user profile: ${error.message}`);
        }
    }

    /**
     * 获取用户资料
     */
    getUserProfile() {
        if (!this.userProfile) {
            throw new Error('No user profile found');
        }
        return this.userProfile;
    }

    /**
     * 删除用户资料
     */
    deleteUserProfile() {
        if (!this.userProfile) {
            throw new Error('No user profile found');
        }
        this.userProfile = null;
        return true;
    }

    /**
     * 检查是否存在用户资料
     */
    hasUserProfile() {
        return this.userProfile !== null;
    }

    // ==================== 通用管理方法 ====================

    /**
     * 获取存储状态统计
     */
    getStats() {
        return {
            userPreferences: this.userPreferences.size,
            userStatistics: this.userStatistics.size,
            totalChatMessages: this.chatMessages.size,
            usersWithChatHistory: this.chatHistories.size,
            totalWords: this.words.size,
            usersWithWords: this.userWords.size,
            hasUserProfile: this.hasUserProfile()
        };
    }

    /**
     * 清空所有数据
     */
    clearAll() {
        this.userPreferences.clear();
        this.userStatistics.clear();
        this.chatHistories.clear();
        this.chatMessages.clear();
        this.words.clear();
        this.userWords.clear();
        this.userProfile = null;
        return true;
    }
}

// 创建单例实例
const storageEngine = new StorageEngine();

module.exports = storageEngine;