# AWS TTS Microservice

轻量化 AWS Polly TTS 微服务

## 使用方法

### 1. 配置环境变量
```bash
cp .env.example .env
# 编辑 .env 文件，填入您的 AWS 凭证
```

### 2. 启动服务
```bash
npm start
```

### 3. API 调用
```bash
# 默认 16kHz 采样率
curl -X POST http://localhost:3011/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello world", "voice": "Ruth"}' \
  --output audio.wav

# 指定 8kHz 采样率（更小文件）
curl -X POST http://localhost:3011/tts \
  -H "Content-Type: application/json" \
  -d '{"text": "Hello world", "voice": "Ruth", "sampleRate": "8000"}' \
  --output audio_8k.wav
```

### 4. Docker 运行
```bash
docker build -t aws-tts .
docker run -p 3011:3011 -e AWS_ACCESS_KEY_ID=xxx -e AWS_SECRET_ACCESS_KEY=xxx aws-tts
```

## 环境变量
- `PORT`: 服务端口 (默认: 3011)  
- `AWS_REGION`: AWS 区域 (默认: us-east-1)
- `AWS_ACCESS_KEY_ID`: AWS 访问密钥
- `AWS_SECRET_ACCESS_KEY`: AWS 密钥