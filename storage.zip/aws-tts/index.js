import { PollyClient, SynthesizeSpeechCommand } from "@aws-sdk/client-polly";
import express from "express";
import dotenv from "dotenv";

// 加载环境变量
dotenv.config();

// 将 ReadableStream 转换为 Buffer
async function streamToBuffer(stream) {
  const chunks = [];
  for await (const chunk of stream) {
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

// 创建 WAV 文件头
function createWavHeader(pcmDataLength, sampleRate, channels = 1, bitsPerSample = 16) {
  const header = Buffer.alloc(44);
  const bytesPerSample = bitsPerSample / 8;
  const blockAlign = channels * bytesPerSample;
  const byteRate = sampleRate * blockAlign;
  
  // RIFF 头部 (12 bytes)
  header.write('RIFF', 0, 4);                           // ChunkID
  header.writeUInt32LE(36 + pcmDataLength, 4);          // ChunkSize (文件大小 - 8)
  header.write('WAVE', 8, 4);                           // Format
  
  // fmt 子块 (24 bytes)
  header.write('fmt ', 12, 4);                          // Subchunk1ID
  header.writeUInt32LE(16, 16);                         // Subchunk1Size (PCM = 16)
  header.writeUInt16LE(1, 20);                          // AudioFormat (PCM = 1)
  header.writeUInt16LE(channels, 22);                   // NumChannels
  header.writeUInt32LE(sampleRate, 24);                 // SampleRate
  header.writeUInt32LE(byteRate, 28);                   // ByteRate
  header.writeUInt16LE(blockAlign, 32);                 // BlockAlign
  header.writeUInt16LE(bitsPerSample, 34);              // BitsPerSample
  
  // data 子块头部 (8 bytes)
  header.write('data', 36, 4);                          // Subchunk2ID
  header.writeUInt32LE(pcmDataLength, 40);              // Subchunk2Size
  
  return header;
}

const app = express();
const port = process.env.PORT || 3011;
const polly = new PollyClient({ region: process.env.AWS_REGION || "us-east-1" });

app.use(express.json());

// TTS 端点 - 只返回 WAV 格式
app.post('/tts', async (req, res) => {
  try {
    const { text, voice = "Ruth", sampleRate = "16000" } = req.body;
    
    if (!text) {
      return res.status(400).json({ error: "Text is required" });
    }

    // 请求 PCM 格式音频流
    const command = new SynthesizeSpeechCommand({
      Engine: "neural", // standard 引擎支持 PCM 输出
      Text: text,
      VoiceId: voice,
      OutputFormat: "pcm",
      SampleRate: sampleRate
    });

    console.log(`Requesting TTS: "${text}" with voice ${voice} at ${sampleRate}Hz`);
    
    const { AudioStream } = await polly.send(command);
    
    if (!AudioStream) {
      throw new Error("No audio returned from Polly");
    }

    // 正确地将 AudioStream (ReadableStream) 转换为 Buffer
    const pcmData = await streamToBuffer(AudioStream);
    console.log(`PCM data length: ${pcmData.length} bytes`);
    
    // 创建 WAV 头部并拼接 PCM 数据
    const sampleRateNum = parseInt(sampleRate);
    const wavHeader = createWavHeader(pcmData.length, sampleRateNum);
    const wavFile = Buffer.concat([wavHeader, pcmData]);
    
    console.log(`WAV file size: ${wavFile.length} bytes (${wavHeader.length} header + ${pcmData.length} data)`);

    res.set({
      'Content-Type': 'audio/wav',
      'Content-Disposition': 'attachment; filename="tts.wav"',
      'Content-Length': wavFile.length.toString()
    });

    // 返回完整的 WAV 文件
    res.end(wavFile);

  } catch (error) {
    console.error('TTS Error:', error);
    res.status(500).json({ error: "TTS generation failed" });
  }
});

// 健康检查
app.get('/health', (req, res) => {
  res.json({ status: 'ok', service: 'aws-tts' });
});

app.listen(port, () => {
  console.log(`AWS TTS service running on port ${port}`);
});
