import { PollyClient, SynthesizeSpeechCommand } from "@aws-sdk/client-polly";
import fs from "fs";

const pollyClient = new PollyClient({ region: "us-east-1" });

async function synthesizeToFile(text, filePath) {
  const command = new SynthesizeSpeechCommand({
    Engine: "neural",
    Text: text,
    VoiceId: "Ruth",
    OutputFormat: "mp3",
  });

  const { AudioStream } = await pollyClient.send(command);

  if (!AudioStream) throw new Error("No audio returned from Polly");

  // AudioStream 是一个 Node.js ReadableStream
  const writeStream = fs.createWriteStream(filePath);
  AudioStream.pipe(writeStream);

  return new Promise((resolve, reject) => {
    writeStream.on("finish", () => resolve(filePath));
    writeStream.on("error", reject);
  });
}

// 测试
synthesizeToFile("Hello! This is AWS Polly speaking.", "output.mp3")
  .then((f) => console.log("Audio saved at", f))
  .catch(console.error);
