const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

// 测试配置
const BASE_URL = 'http://localhost:3010';
const API_KEY = 'changeme'; // 使用默认API密钥，实际使用时请修改

// 创建测试用的axios实例
const client = axios.create({
    baseURL: BASE_URL,
    headers: {
        'X-API-Key': API_KEY
    }
});

// 测试用例
class AWSSTTServiceTester {
    constructor() {
        this.testResults = [];
    }

    async runAllTests() {
        console.log('🚀 开始运行AWS STT服务测试...\n');

        await this.testHealthCheck();
        await this.testSingleSTT();
        await this.testBatchSTT();
        await this.testErrorHandling();
        await this.testAWSCredentials();

        this.printSummary();
    }

    async testHealthCheck() {
        console.log('🏥 测试健康检查端点...');
        
        try {
            const response = await axios.get(`${BASE_URL}/health`);
            
            if (response.status === 200 && response.data.status === 'healthy') {
                console.log('✅ 健康检查测试通过');
                console.log(`   服务: ${response.data.service}`);
                console.log(`   区域: ${response.data.region}`);
                console.log(`   时间: ${response.data.timestamp}`);
                this.testResults.push({ test: 'Health Check', status: 'PASS' });
            } else {
                throw new Error('健康检查返回异常状态');
            }
        } catch (error) {
            console.log('❌ 健康检查测试失败:', error.message);
            this.testResults.push({ test: 'Health Check', status: 'FAIL', error: error.message });
        }
        console.log('');
    }

    async testSingleSTT() {
        console.log('🎤 测试单文件语音转文字...');
        
        try {
            // 检查测试音频文件是否存在
            const audioFile = path.join(__dirname, '../testing.wav');
            if (!fs.existsSync(audioFile)) {
                console.log('⚠️  测试音频文件不存在，跳过STT测试');
                this.testResults.push({ test: 'Single STT', status: 'SKIP', error: '测试音频文件不存在' });
                return;
            }

            const formData = new FormData();
            formData.append('audio', fs.createReadStream(audioFile));
            formData.append('language', 'zh-CN');

            const response = await client.post('/speech-to-text', formData, {
                headers: {
                    ...formData.getHeaders()
                },
                timeout: 30000 // 30秒超时
            });

            if (response.status === 200 && response.data.success) {
                console.log('✅ 单文件STT测试通过');
                console.log(`   识别结果: "${response.data.data.recognizedText}"`);
                console.log(`   处理时间: ${response.data.data.processingTime}`);
                console.log(`   音频信息: ${response.data.data.audioInfo.filename} (${response.data.data.audioInfo.size} bytes)`);
                this.testResults.push({ test: 'Single STT', status: 'PASS' });
            } else {
                throw new Error('STT响应格式异常');
            }
        } catch (error) {
            console.log('❌ 单文件STT测试失败:', error.message);
            if (error.response) {
                console.log(`   状态码: ${error.response.status}`);
                console.log(`   错误详情: ${JSON.stringify(error.response.data, null, 2)}`);
            }
            this.testResults.push({ test: 'Single STT', status: 'FAIL', error: error.message });
        }
        console.log('');
    }

    async testBatchSTT() {
        console.log('📦 测试批量语音转文字...');
        
        try {
            // 检查测试音频文件是否存在
            const audioFile = path.join(__dirname, '../testing.wav');
            if (!fs.existsSync(audioFile)) {
                console.log('⚠️  测试音频文件不存在，跳过批量STT测试');
                this.testResults.push({ test: 'Batch STT', status: 'SKIP', error: '测试音频文件不存在' });
                return;
            }

            const formData = new FormData();
            // 添加同一个文件两次来模拟批量处理
            formData.append('audio', fs.createReadStream(audioFile));
            formData.append('audio', fs.createReadStream(audioFile));
            formData.append('language', 'zh-CN');

            const response = await client.post('/batch-speech-to-text', formData, {
                headers: {
                    ...formData.getHeaders()
                },
                timeout: 60000 // 60秒超时
            });

            if (response.status === 200 && response.data.success) {
                const { results, summary } = response.data.data;
                console.log('✅ 批量STT测试通过');
                console.log(`   处理文件数: ${summary.total}`);
                console.log(`   成功数量: ${summary.successful}`);
                console.log(`   失败数量: ${summary.failed}`);
                console.log(`   处理时间: ${response.data.data.processingTime}`);
                
                results.forEach((result, index) => {
                    if (result.success) {
                        console.log(`   文件${index + 1}: "${result.recognizedText}"`);
                    } else {
                        console.log(`   文件${index + 1}: 失败 - ${result.error}`);
                    }
                });
                
                this.testResults.push({ test: 'Batch STT', status: 'PASS' });
            } else {
                throw new Error('批量STT响应格式异常');
            }
        } catch (error) {
            console.log('❌ 批量STT测试失败:', error.message);
            if (error.response) {
                console.log(`   状态码: ${error.response.status}`);
                console.log(`   错误详情: ${JSON.stringify(error.response.data, null, 2)}`);
            }
            this.testResults.push({ test: 'Batch STT', status: 'FAIL', error: error.message });
        }
        console.log('');
    }

    async testErrorHandling() {
        console.log('🔒 测试错误处理...');
        
        // 测试无效API密钥
        try {
            await axios.get(`${BASE_URL}/speech-to-text`, {
                headers: { 'X-API-Key': 'invalid-key' }
            });
            console.log('❌ API密钥验证测试失败: 应该返回401错误');
            this.testResults.push({ test: 'API Key Validation', status: 'FAIL' });
        } catch (error) {
            if (error.response && error.response.status === 401) {
                console.log('✅ API密钥验证测试通过');
                this.testResults.push({ test: 'API Key Validation', status: 'PASS' });
            } else {
                console.log('❌ API密钥验证测试失败: 意外的错误', error.message);
                this.testResults.push({ test: 'API Key Validation', status: 'FAIL', error: error.message });
            }
        }

        // 测试无效端点
        try {
            await client.get('/invalid-endpoint');
            console.log('❌ 404错误处理测试失败: 应该返回404错误');
            this.testResults.push({ test: '404 Handling', status: 'FAIL' });
        } catch (error) {
            if (error.response && error.response.status === 404) {
                console.log('✅ 404错误处理测试通过');
                this.testResults.push({ test: '404 Handling', status: 'PASS' });
            } else {
                console.log('❌ 404错误处理测试失败: 意外的错误', error.message);
                this.testResults.push({ test: '404 Handling', status: 'FAIL', error: error.message });
            }
        }

        // 测试缺少音频文件
        try {
            const formData = new FormData();
            formData.append('language', 'zh-CN');

            await client.post('/speech-to-text', formData, {
                headers: { ...formData.getHeaders() }
            });
            console.log('❌ 音频文件验证测试失败: 应该返回400错误');
            this.testResults.push({ test: 'Audio File Validation', status: 'FAIL' });
        } catch (error) {
            if (error.response && error.response.status === 400) {
                console.log('✅ 音频文件验证测试通过');
                this.testResults.push({ test: 'Audio File Validation', status: 'PASS' });
            } else {
                console.log('❌ 音频文件验证测试失败: 意外的错误', error.message);
                this.testResults.push({ test: 'Audio File Validation', status: 'FAIL', error: error.message });
            }
        }

        console.log('');
    }

    printSummary() {
        console.log('📊 测试结果汇总:');
        console.log('=====================================');
        
        let passCount = 0;
        let failCount = 0;

        this.testResults.forEach(result => {
            const status = result.status === 'PASS' ? '✅ PASS' : 
                          result.status === 'SKIP' ? '⏭️  SKIP' : '❌ FAIL';
            console.log(`${result.test.padEnd(25)} ${status}`);
            if (result.status === 'PASS') {
                passCount++;
            } else if (result.status === 'FAIL') {
                failCount++;
                if (result.error) {
                    console.log(`    错误: ${result.error}`);
                }
            }
            // SKIP状态不计入成功或失败
        });

        const totalTests = this.testResults.filter(r => r.status !== 'SKIP').length;
        console.log('=====================================');
        console.log(`总计: ${this.testResults.length} 个测试`);
        console.log(`通过: ${passCount} 个`);
        console.log(`失败: ${failCount} 个`);
        console.log(`跳过: ${this.testResults.length - totalTests} 个`);
        if (totalTests > 0) {
            console.log(`成功率: ${Math.round((passCount / totalTests) * 100)}%`);
        }

        if (failCount === 0) {
            console.log('🎉 所有测试通过！');
        } else {
            console.log('⚠️  部分测试失败，请检查服务配置');
        }
    }
    async testAWSCredentials() {
        console.log('🔑 测试AWS认证配置...');
        
        try {
            // 测试通过健康检查验证AWS配置
            const response = await axios.get(`${BASE_URL}/health`);
            
            if (response.status === 200 && response.data.service === 'aws-transcribe-stt') {
                console.log('✅ AWS认证配置测试通过');
                console.log(`   AWS区域: ${response.data.region}`);
                this.testResults.push({ test: 'AWS Credentials', status: 'PASS' });
            } else {
                throw new Error('AWS服务未正确初始化');
            }
        } catch (error) {
            console.log('❌ AWS认证配置测试失败:', error.message);
            this.testResults.push({ test: 'AWS Credentials', status: 'FAIL', error: error.message });
        }
        console.log('');
    }

    printSummary() {
        console.log('📊 测试结果汇总:');
        console.log('=====================================');
        
        let passCount = 0;
        let failCount = 0;

        this.testResults.forEach(result => {
            const status = result.status === 'PASS' ? '✅ PASS' : 
                          result.status === 'SKIP' ? '⏭️  SKIP' : '❌ FAIL';
            console.log(`${result.test.padEnd(25)} ${status}`);
            if (result.status === 'PASS') {
                passCount++;
            } else if (result.status === 'FAIL') {
                failCount++;
                if (result.error) {
                    console.log(`    错误: ${result.error}`);
                }
            }
        });

        const totalTests = this.testResults.filter(r => r.status !== 'SKIP').length;
        console.log('=====================================');
        console.log(`总计: ${this.testResults.length} 个测试`);
        console.log(`通过: ${passCount} 个`);
        console.log(`失败: ${failCount} 个`);
        console.log(`跳过: ${this.testResults.length - totalTests} 个`);
        if (totalTests > 0) {
            console.log(`成功率: ${Math.round((passCount / totalTests) * 100)}%`);
        }

        if (failCount === 0) {
            console.log('🎉 所有测试通过！');
        } else {
            console.log('⚠️  部分测试失败，请检查服务配置和AWS凭证');
        }
    }
}

// 运行测试
async function runTests() {
    const tester = new AWSSTTServiceTester();
    
    try {
        await tester.runAllTests();
    } catch (error) {
        console.error('测试运行出错:', error.message);
        process.exit(1);
    }
}

// 如果直接运行此脚本则执行测试
if (require.main === module) {
    console.log('AWS STT Service 测试工具');
    console.log('============================');
    console.log('确保服务正在运行: npm start 或 docker-compose up');
    console.log('确保已配置正确的AWS凭证');
    console.log('');
    
    setTimeout(() => {
        runTests();
    }, 1000);
}

module.exports = AWSSTTServiceTester;