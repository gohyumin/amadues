# AWS STT Service - 语音转文字微服务

基于AWS Transcribe Streaming的语音转文字(Speech-to-Text)微服务，使用纯JavaScript实现，提供REST API接口。

## 功能特性

- 🎯 AWS Transcribe Streaming 集成 (AWS SDK v3)
- 🔊 支持多种音频格式 (WAV, MP3, M4A, AAC, OGG, FLAC)
- 🚀 RESTful API 接口
- 📦 Docker 容器化部署
- 🔒 API密钥认证
- 📊 批量处理支持
- 💾 临时文件自动清理
- 🏥 健康检查端点
- ⚡ 纯JavaScript实现，无Python依赖
- 🌐 支持实时流式转录

## 快速开始

### 环境要求

- Node.js >= 16.0.0
- AWS 账户和访问密钥

### 本地开发

1. **安装依赖**
```bash
npm install
```

2. **配置环境变量**
创建 `.env` 文件：
```bash
# AWS 配置
AWS_ACCESS_KEY_ID=your_aws_access_key_id
AWS_SECRET_ACCESS_KEY=your_aws_secret_access_key
AWS_REGION=us-east-1

# 服务配置
PORT=3010
API_KEY=your_secure_api_key

# AWS Transcribe 特定配置
TRANSCRIBE_LANGUAGE_CODE=zh-CN
TRANSCRIBE_MEDIA_SAMPLE_RATE_HZ=16000
TRANSCRIBE_MEDIA_FORMAT=wav
```

3. **启动服务**
```bash
# 开发模式
npm run dev

# 生产模式
npm start
```

### Docker 部署

1. **使用 Docker Compose**
```bash
# 构建并启动
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

2. **直接使用 Docker**
```bash
# 构建镜像
docker build -t aws-stt-service .

# 运行容器
docker run -d \
  -p 3010:3010 \
  -e AWS_ACCESS_KEY_ID=your_access_key_id \
  -e AWS_SECRET_ACCESS_KEY=your_secret_access_key \
  -e AWS_REGION=us-east-1 \
  -e API_KEY=your_api_key \
  --name aws-stt-service \
  aws-stt-service
```

## API 文档

### 认证

所有API请求都需要在请求头中包含API密钥：
```
X-API-Key: your_api_key
```

### 端点

#### 1. 健康检查

**GET** `/health`

响应示例：
```json
{
  "status": "healthy",
  "service": "aws-transcribe-stt",
  "region": "us-east-1",
  "timestamp": "2024-01-01T00:00:00.000Z",
  "version": "2.0.0"
}
```

#### 2. 语音转文字

**POST** `/speech-to-text`

**请求参数：**
- `audio` (file, required): 音频文件
- `language` (string, optional): 语言代码，默认为 'zh-CN'

**请求示例：**
```bash
curl -X POST \
  -H "X-API-Key: mykey" \
  -F "audio=@testing.wav" \
  -F "language=zh-CN" \
  http://localhost:3010/speech-to-text
```

**响应示例：**
```json
{
  "success": true,
  "data": {
    "recognizedText": "你好，这是一段测试语音",
    "language": "zh-CN",
    "processingTime": "1234ms",
    "audioInfo": {
      "filename": "test.wav",
      "size": 1024000,
      "mimetype": "audio/wav"
    }
  },
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

#### 3. 批量语音转文字

**POST** `/batch-speech-to-text`

**请求参数：**
- `audio` (files[], required): 多个音频文件 (最多10个)
- `language` (string, optional): 语言代码，默认为 'zh-CN'

**请求示例：**
```bash
curl -X POST \
  -H "X-API-Key: your_api_key" \
  -F "audio=@test1.wav" \
  -F "audio=@test2.wav" \
  -F "language=zh-CN" \
  http://localhost:3000/batch-speech-to-text
```

**响应示例：**
```json
{
  "success": true,
  "data": {
    "results": [
      {
        "filename": "test1.wav",
        "success": true,
        "recognizedText": "第一段测试语音",
        "size": 1024000,
        "mimetype": "audio/wav"
      },
      {
        "filename": "test2.wav",
        "success": true,
        "recognizedText": "第二段测试语音",
        "size": 2048000,
        "mimetype": "audio/wav"
      }
    ],
    "summary": {
      "total": 2,
      "successful": 2,
      "failed": 0
    },
    "language": "zh-CN",
    "processingTime": "2456ms"
  },
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

### 错误处理

错误响应格式：
```json
{
  "success": false,
  "error": "错误类型",
  "details": "详细错误信息",
  "processingTime": "123ms",
  "timestamp": "2024-01-01T00:00:00.000Z"
}
```

常见错误码：
- `400` - 请求参数错误
- `401` - API密钥无效
- `413` - 文件过大 (>50MB)
- `500` - 服务器内部错误

## 配置说明

### 环境变量

| 变量名 | 必需 | 默认值 | 说明 |
|--------|------|--------|------|
| `AWS_ACCESS_KEY_ID` | 是 | - | AWS访问密钥ID |
| `AWS_SECRET_ACCESS_KEY` | 是 | - | AWS访问密钥 |
| `AWS_REGION` | 否 | us-east-1 | AWS服务区域 |
| `PORT` | 否 | 3010 | 服务端口 |
| `API_KEY` | 否 | changeme | API访问密钥 |
| `TRANSCRIBE_LANGUAGE_CODE` | 否 | zh-CN | 默认语言代码 |
| `TRANSCRIBE_MEDIA_SAMPLE_RATE_HZ` | 否 | 16000 | 音频采样率 |
| `TRANSCRIBE_MEDIA_FORMAT` | 否 | wav | 音频格式 |

### AWS IAM 权限要求

需要为AWS访问密钥配置以下IAM策略：

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "transcribe:StartStreamTranscription"
            ],
            "Resource": "*"
        }
    ]
}
```

### 文件限制

- 单文件大小限制：50MB
- 批量处理文件数量：最多10个
- 支持格式：WAV, MP3, M4A, AAC, OGG, FLAC
- 推荐音频格式：16kHz, 单声道, PCM

## 开发指南

### 项目结构
```
aws-stt-service/
├── server.js           # 主服务文件
├── stt-service.js      # AWS Transcribe STT服务模块
├── package.json        # 项目配置
├── Dockerfile          # Docker镜像构建文件
├── docker-compose.yml  # Docker Compose配置
├── test.js            # 测试文件
├── .env.example       # 环境变量模板
├── README.md          # 项目文档
└── temp/              # 临时文件目录
```

### 脚本命令

```bash
# 启动开发服务器
npm run dev

# 启动生产服务器
npm start

# 运行测试
npm test

# 代码检查
npm run lint

# Docker构建
npm run docker:build

# Docker运行
npm run docker:run
```

## 故障排除

### 常见问题

1. **文件上传失败**
   - 检查文件格式是否支持
   - 确认文件大小不超过50MB

3. **Docker构建失败**
   - 检查Docker和docker-compose版本
   - 确保网络连接正常以下载依赖

4. **语音识别失败**
   - 确认音频文件格式正确
   - 检查音频文件质量和清晰度
   - 验证语言代码设置正确

### 日志查看

```bash
# Docker Compose日志
docker-compose logs -f stt-service

# 容器日志
docker logs -f stt-service
```

## 许可证

MIT License

## 贡献

欢迎提交Issue和Pull Request！