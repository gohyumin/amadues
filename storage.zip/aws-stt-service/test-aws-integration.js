const AWSTranscribeSTTModule = require('./stt-service');

// 测试AWS Transcribe集成
async function testAWSTranscribe() {
    console.log('🧪 测试改进后的AWS Transcribe集成...\n');

    try {
        // 初始化服务
        const sttService = new AWSTranscribeSTTModule();
        console.log('✅ AWS Transcribe服务初始化成功\n');

        // 测试健康检查
        const healthStatus = await sttService.healthCheck();
        console.log('🏥 健康检查结果:');
        console.log(JSON.stringify(healthStatus, null, 2));
        console.log('');

        // 测试支持的语言
        const supportedLanguages = sttService.getSupportedLanguages();
        console.log('🌍 支持的语言:');
        supportedLanguages.slice(0, 5).forEach(lang => {
            console.log(`   ${lang.code}: ${lang.name}`);
        });
        console.log(`   ... 共${supportedLanguages.length}种语言\n`);

        // 如果有测试音频文件，尝试转录
        const fs = require('fs');
        const path = require('path');
        const testAudioFile = path.join(__dirname, '../testing.wav');
        
        if (fs.existsSync(testAudioFile)) {
            console.log('🎵 开始测试音频转录...');
            const startTime = Date.now();
            
            try {
                const transcript = await sttService.speechToText(testAudioFile, 'zh-CN');
                const processingTime = Date.now() - startTime;
                
                console.log('✅ 转录成功！');
                console.log(`   结果: "${transcript}"`);
                console.log(`   处理时间: ${processingTime}ms`);
            } catch (transcriptionError) {
                console.log('❌ 转录失败:', transcriptionError.message);
                
                // 如果是AWS认证相关错误，提供帮助信息
                if (transcriptionError.message.includes('AWS认证') || 
                    transcriptionError.message.includes('访问密钥') ||
                    transcriptionError.message.includes('权限')) {
                    console.log('\n💡 AWS认证问题解决方案:');
                    console.log('   1. 检查 .env 文件中的 AWS_ACCESS_KEY_ID 和 AWS_SECRET_ACCESS_KEY');
                    console.log('   2. 确保AWS账户有 transcribe:StartStreamTranscription 权限');
                    console.log('   3. 检查AWS区域设置是否正确');
                }
            }
        } else {
            console.log('⏭️  未找到测试音频文件，跳过转录测试');
            console.log(`   请将音频文件放置在: ${testAudioFile}`);
        }

    } catch (error) {
        console.log('❌ 测试失败:', error.message);
        console.log('\n🔧 可能的解决方案:');
        console.log('   1. 检查AWS凭证配置');
        console.log('   2. 检查网络连接');
        console.log('   3. 检查AWS区域设置');
        console.log('   4. 确保已安装所有依赖: npm install');
    }
}

// 运行测试
if (require.main === module) {
    testAWSTranscribe();
}

module.exports = testAWSTranscribe;