const { TranscribeStreamingClient, StartStreamTranscriptionCommand } = require('@aws-sdk/client-transcribe-streaming');
const { fromEnv } = require('@aws-sdk/credential-provider-env');
const fs = require('fs');
const path = require('path');

/**
 * AWS Transcribe STT Module - JavaScript版本
 * 基于 AWS Transcribe Streaming API
 */
class AWSTranscribeSTTModule {
    constructor(region = null) {
        this.region = region || process.env.AWS_REGION || 'us-east-1';
        
        // 验证必要的环境变量
        if (!process.env.AWS_ACCESS_KEY_ID || !process.env.AWS_SECRET_ACCESS_KEY) {
            throw new Error('AWS credentials are required (AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY)');
        }
        
        // 初始化AWS Transcribe客户端
        this.transcribeClient = new TranscribeStreamingClient({
            region: this.region,
            credentials: fromEnv()
        });
        
        console.log(`[STT] AWS Transcribe STT Module initialized - Region: ${this.region}`);
    }

    /**
     * 将语言代码转换为AWS Transcribe支持的格式
     * @param {string} language - 输入的语言代码
     * @returns {string} AWS Transcribe支持的语言代码
     */
    mapLanguageCode(language) {
        const languageMap = {
            'zh-CN': 'zh-CN',
            'zh-TW': 'zh-TW', 
            'en-US': 'en-US',
            'en-GB': 'en-GB',
            'ja-JP': 'ja-JP',
            'ko-KR': 'ko-KR',
            'es-ES': 'es-ES',
            'fr-FR': 'fr-FR',
            'de-DE': 'de-DE',
            'pt-BR': 'pt-BR',
            'it-IT': 'it-IT',
            'ru-RU': 'ru-RU',
            'ar-AE': 'ar-AE'
        };
        
        return languageMap[language] || 'zh-CN';
    }

    /**
     * 创建音频流生成器 - 基于文件流
     * @param {string} audioFilePath - 音频文件路径
     * @param {number} chunkSize - 每次读取的块大小
     */
    async* createAudioStreamFromFile(audioFilePath, chunkSize = 1024 * 16) {
        const fs = require('fs');
        const stream = fs.createReadStream(audioFilePath, { highWaterMark: chunkSize });
        
        for await (const chunk of stream) {
            yield {
                AudioEvent: {
                    AudioChunk: chunk
                }
            };
        }
    }

    /**
     * 创建音频流生成器 - 基于Buffer
     * @param {Buffer} audioData - PCM音频数据
     * @param {number} chunkSize - 每次发送的音频块大小
     */
    async* createAudioStream(audioData, chunkSize = 1024 * 16) {
        for (let i = 0; i < audioData.length; i += chunkSize) {
            const chunk = audioData.slice(i, i + chunkSize);
            yield {
                AudioEvent: {
                    AudioChunk: chunk
                }
            };
        }
    }

    /**
     * 语音转文字 - 处理音频文件
     * @param {string} audioFilePath - 音频文件路径
     * @param {string} language - 语言代码，默认 'zh-CN'
     * @returns {Promise<string>} 识别的文本
     */
    async speechToText(audioFilePath, language = 'zh-CN') {
        try {
            console.log(`[STT] 开始处理音频文件: ${audioFilePath}`);
            console.log(`[STT] 语言设置: ${language}`);

            if (!fs.existsSync(audioFilePath)) {
                throw new Error(`音频文件不存在: ${audioFilePath}`);
            }

            const awsLanguageCode = this.mapLanguageCode(language);
            console.log(`[STT] AWS语言代码: ${awsLanguageCode}`);

            // 检查文件扩展名，决定是否需要转换
            const fileExt = path.extname(audioFilePath).toLowerCase();
            let audioStream;
            
            if (fileExt === '.wav' || fileExt === '.pcm') {
                // 对于WAV/PCM文件，直接使用文件流（更高效）
                console.log(`[STT] 使用文件流处理: ${fileExt}`);
                audioStream = this.createAudioStreamFromFile(audioFilePath);
            } else {
                // 对于其他格式，读取到Buffer中处理
                console.log(`[STT] 使用Buffer处理: ${fileExt}`);
                const audioBuffer = fs.readFileSync(audioFilePath);
                audioStream = this.createAudioStream(audioBuffer);
            }

            const params = {
                LanguageCode: awsLanguageCode,
                MediaSampleRateHertz: "16000",  // 必须是字符串
                MediaEncoding: 'pcm',
                AudioStream: audioStream
            };

            console.log(`[STT] 开始AWS Transcribe流式转录...`);
            const command = new StartStreamTranscriptionCommand(params);
            const response = await this.transcribeClient.send(command);

            let transcript = '';
            
            for await (const event of response.TranscriptResultStream) {
                if (event.TranscriptEvent) {
                    const results = event.TranscriptEvent.Transcript.Results;
                    
                    for (const result of results) {
                        if (result.IsPartial === false) {
                            for (const alternative of result.Alternatives) {
                                if (alternative.Transcript) {
                                    transcript += alternative.Transcript + ' ';
                                    console.log(`[STT] 识别片段: ${alternative.Transcript}`);
                                }
                            }
                        }
                    }
                }
            }

            const finalTranscript = transcript.trim();
            console.log(`[STT] 最终转录结果: ${finalTranscript}`);
            
            return finalTranscript;

        } catch (error) {
            console.error(`[STT] 转录错误: ${error.message}`);
            
            if (error.name === 'InvalidSignatureException') {
                throw new Error('AWS认证失败，请检查访问密钥');
            } else if (error.name === 'UnrecognizedClientException') {
                throw new Error('AWS访问密钥无效');
            } else if (error.name === 'AccessDeniedException') {
                throw new Error('AWS权限不足，请检查IAM策略');
            } else if (error.message.includes('UnsupportedLanguage')) {
                throw new Error(`不支持的语言: ${language}`);
            }
            
            throw new Error(`语音转录失败: ${error.message}`);
        }
    }

    /**
     * 批量处理音频文件
     * @param {Array<string>} audioFilePaths - 音频文件路径数组
     * @param {string} language - 语言代码
     * @returns {Promise<Array<Object>>} 转录结果数组
     */
    async batchSpeechToText(audioFilePaths, language = 'zh-CN') {
        const results = [];
        
        console.log(`[STT] 开始批量处理 ${audioFilePaths.length} 个文件`);
        
        for (let i = 0; i < audioFilePaths.length; i++) {
            const filePath = audioFilePaths[i];
            console.log(`[STT] 处理文件 ${i + 1}/${audioFilePaths.length}: ${filePath}`);
            
            try {
                const transcript = await this.speechToText(filePath, language);
                results.push({
                    filePath: filePath,
                    transcript: transcript,
                    success: true,
                    error: null
                });
            } catch (error) {
                console.error(`[STT] 文件处理失败 ${filePath}: ${error.message}`);
                results.push({
                    filePath: filePath,
                    transcript: '',
                    success: false,
                    error: error.message
                });
            }
        }
        
        console.log(`[STT] 批量处理完成，成功: ${results.filter(r => r.success).length}/${results.length}`);
        return results;
    }

    /**
     * 获取支持的语言列表
     * @returns {Array<Object>} 支持的语言列表
     */
    getSupportedLanguages() {
        return [
            { code: 'zh-CN', name: '中文(简体)' },
            { code: 'zh-TW', name: '中文(繁体)' },
            { code: 'en-US', name: 'English (US)' },
            { code: 'en-GB', name: 'English (UK)' },
            { code: 'ja-JP', name: '日本語' },
            { code: 'ko-KR', name: '한국어' },
            { code: 'es-ES', name: 'Español' },
            { code: 'fr-FR', name: 'Français' },
            { code: 'de-DE', name: 'Deutsch' },
            { code: 'pt-BR', name: 'Português (Brasil)' },
            { code: 'it-IT', name: 'Italiano' },
            { code: 'ru-RU', name: 'Русский' },
            { code: 'ar-AE', name: 'العربية' }
        ];
    }

    /**
     * 检查服务健康状态
     * @returns {Promise<Object>} 健康状态信息
     */
    async healthCheck() {
        try {
            return {
                status: 'healthy',
                service: 'aws-transcribe-stt',
                region: this.region,
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            return {
                status: 'unhealthy',
                service: 'aws-transcribe-stt',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * 测试AWS连接
     * @returns {Promise<boolean>} 连接测试结果
     */
    async testConnection() {
        try {
            console.log(`[STT] 测试AWS Transcribe连接...`);
            
            // 通过创建客户端来测试AWS凭证和连接
            const testClient = new (require('@aws-sdk/client-transcribe-streaming').TranscribeStreamingClient)({
                region: this.region,
                credentials: require('@aws-sdk/credential-provider-env').fromEnv()
            });

            // 简单的连接测试 - 只是验证客户端可以正常创建
            if (testClient) {
                console.log(`[STT] AWS连接测试成功 - 区域: ${this.region}`);
                return true;
            }
            
            return false;
        } catch (error) {
            console.error(`[STT] AWS连接测试失败:`, error.message);
            
            // 提供更具体的错误信息
            if (error.name === 'CredentialsProviderError') {
                console.error(`[STT] AWS凭证错误: 请检查 AWS_ACCESS_KEY_ID 和 AWS_SECRET_ACCESS_KEY`);
            } else if (error.message.includes('Region')) {
                console.error(`[STT] AWS区域错误: 请检查 AWS_REGION 设置`);
            }
            
            return false;
        }
    }
}

module.exports = AWSTranscribeSTTModule;
