const express = require('express');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs-extra');
const path = require('path');
require('dotenv').config();

const AWSTranscribeSTTModule = require('./stt-service');

const app = express();
const port = process.env.PORT || 3010;

// 中间件
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS配置 - 允许跨域请求
app.use((req, res, next) => {
    // 允许所有来源的请求（开发环境）
    res.header('Access-Control-Allow-Origin', '*');
    
    // 允许的HTTP方法
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    
    // 允许的请求头
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization, X-API-Key');
    
    // 预检请求的有效期（秒）
    res.header('Access-Control-Max-Age', '86400');
    
    // 处理预检请求
    if (req.method === 'OPTIONS') {
        res.status(200).end();
    } else {
        next();
    }
});

// 配置项
const AWS_ACCESS_KEY_ID = process.env.AWS_ACCESS_KEY_ID;
const AWS_SECRET_ACCESS_KEY = process.env.AWS_SECRET_ACCESS_KEY;
const AWS_REGION = process.env.AWS_REGION || 'us-east-1';
const API_KEY = process.env.API_KEY || 'changeme';

// 验证必要的环境变量
if (!AWS_ACCESS_KEY_ID || !AWS_SECRET_ACCESS_KEY) {
    console.error('Error: AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY environment variables are required');
    process.exit(1);
}

// 创建临时文件目录
const tempDir = path.join(__dirname, 'temp');
fs.ensureDirSync(tempDir);

// 配置文件上传
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, tempDir);
    },
    filename: (req, file, cb) => {
        const uniqueId = uuidv4();
        const ext = path.extname(file.originalname);
        cb(null, `${uniqueId}${ext}`);
    }
});

const upload = multer({ 
    storage: storage,
    limits: {
        fileSize: 50 * 1024 * 1024, // 50MB limit
    },
    fileFilter: (req, file, cb) => {
        // 检查文件类型 - 接受 audio/* 和常见音频文件扩展名
        const isAudioMime = file.mimetype.startsWith('audio/');
        const isWavFile = file.originalname.toLowerCase().endsWith('.wav');
        const isAudioFile = file.originalname.match(/\.(wav|mp3|m4a|aac|ogg|flac)$/i);
        
        console.log(`文件检查: ${file.originalname}, MIME: ${file.mimetype}`);
        
        if (isAudioMime || isWavFile || isAudioFile) {
            cb(null, true);
        } else {
            cb(new Error('Only audio files are allowed'), false);
        }
    }
});

// API密钥验证中间件
function validateApiKey(req, res, next) {
    const apiKey = req.headers['x-api-key'];
    if (!apiKey || apiKey !== API_KEY) {
        return res.status(401).json({ error: 'Unauthorized: Invalid API key' });
    }
    next();
}

// STT服务实例
const sttService = new AWSTranscribeSTTModule(AWS_REGION);

// 健康检查端点
app.get('/health', (req, res) => {
    res.json({ 
        status: 'healthy', 
        service: 'stt-service',
        timestamp: new Date().toISOString(),
        version: require('./package.json').version
    });
});

// STT路由
app.post('/speech-to-text', validateApiKey, upload.single('audio'), async (req, res) => {
    const startTime = Date.now();
    let tempFilePath = null;

    try {
        const { language = 'zh-CN' } = req.body;

        if (!req.file) {
            return res.status(400).json({ 
                error: 'Bad Request: audio file is required' 
            });
        }

        tempFilePath = req.file.path;

        console.log(`处理STT请求`);
        console.log(`语言: ${language}`);
        console.log(`音频文件: ${req.file.originalname}`);
        console.log(`文件大小: ${req.file.size} bytes`);
        console.log(`临时文件路径: ${tempFilePath}`);

        // 调用STT服务
        const recognizedText = await sttService.speechToText(tempFilePath, language);

        const processingTime = Date.now() - startTime;

        const response = {
            success: true,
            data: {
                recognizedText: recognizedText || '',
                language: language,
                processingTime: `${processingTime}ms`,
                audioInfo: {
                    filename: req.file.originalname,
                    size: req.file.size,
                    mimetype: req.file.mimetype
                }
            },
            timestamp: new Date().toISOString()
        };

        console.log(`STT处理完成: ${processingTime}ms`);
        console.log(`识别结果: ${recognizedText}`);

        res.json(response);

    } catch (error) {
        console.error('STT处理出错:', error);
        
        const processingTime = Date.now() - startTime;
        
        res.status(500).json({
            success: false,
            error: 'Speech recognition failed',
            details: error.message,
            processingTime: `${processingTime}ms`,
            timestamp: new Date().toISOString()
        });
    } finally {
        // 清理临时文件
        if (tempFilePath) {
            fs.remove(tempFilePath).catch(err => {
                console.error('清理临时文件失败:', err);
            });
        }
    }
});

// 批量STT路由
app.post('/batch-speech-to-text', validateApiKey, upload.array('audio', 10), async (req, res) => {
    const startTime = Date.now();
    let tempFilePaths = [];

    try {
        const { language = 'zh-CN' } = req.body;

        if (!req.files || req.files.length === 0) {
            return res.status(400).json({ 
                error: 'Bad Request: at least one audio file is required' 
            });
        }

        tempFilePaths = req.files.map(file => file.path);

        console.log(`处理批量STT请求`);
        console.log(`语言: ${language}`);
        console.log(`文件数量: ${req.files.length}`);

        const results = [];

        // 逐个处理文件
        for (let i = 0; i < req.files.length; i++) {
            const file = req.files[i];
            const filePath = file.path;
            
            try {
                console.log(`处理文件 ${i + 1}/${req.files.length}: ${file.originalname}`);
                const recognizedText = await sttService.speechToText(filePath, language);
                
                results.push({
                    filename: file.originalname,
                    success: true,
                    recognizedText: recognizedText || '',
                    size: file.size,
                    mimetype: file.mimetype
                });
                
                console.log(`文件 ${file.originalname} 处理完成: ${recognizedText}`);
            } catch (error) {
                console.error(`文件 ${file.originalname} 处理失败:`, error);
                results.push({
                    filename: file.originalname,
                    success: false,
                    error: error.message,
                    size: file.size,
                    mimetype: file.mimetype
                });
            }
        }

        const processingTime = Date.now() - startTime;
        const successCount = results.filter(r => r.success).length;

        const response = {
            success: true,
            data: {
                results: results,
                summary: {
                    total: results.length,
                    successful: successCount,
                    failed: results.length - successCount
                },
                language: language,
                processingTime: `${processingTime}ms`
            },
            timestamp: new Date().toISOString()
        };

        console.log(`批量STT处理完成: ${processingTime}ms`);
        console.log(`成功: ${successCount}/${results.length}`);

        res.json(response);

    } catch (error) {
        console.error('批量STT处理出错:', error);
        
        const processingTime = Date.now() - startTime;
        
        res.status(500).json({
            success: false,
            error: 'Batch speech recognition failed',
            details: error.message,
            processingTime: `${processingTime}ms`,
            timestamp: new Date().toISOString()
        });
    } finally {
        // 清理所有临时文件
        for (const filePath of tempFilePaths) {
            fs.remove(filePath).catch(err => {
                console.error('清理临时文件失败:', err);
            });
        }
    }
});

// 错误处理中间件
app.use((error, req, res, next) => {
    console.error('Unhandled error:', error);
    
    if (error instanceof multer.MulterError) {
        if (error.code === 'LIMIT_FILE_SIZE') {
            return res.status(413).json({
                error: 'File too large',
                details: 'Audio file size must be less than 50MB'
            });
        }
        return res.status(400).json({
            error: 'File upload error',
            details: error.message
        });
    }
    
    res.status(500).json({
        error: 'Internal server error',
        details: error.message
    });
});

// 404处理
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'Not Found',
        details: 'The requested endpoint does not exist'
    });
});

// 启动服务器
app.listen(port, async () => {
    console.log(`STT Service running on port ${port}`);
    console.log(`Health check: http://localhost:${port}/health`);
    console.log(`STT Endpoint: POST http://localhost:${port}/speech-to-text`);
    console.log(`Batch STT Endpoint: POST http://localhost:${port}/batch-speech-to-text`);
    
    // 测试AWS连接
    try {
        const isConnected = await sttService.testConnection();
        if (isConnected) {
            console.log(`✅ AWS Speech Services connection successful`);
        } else {
            console.log(`❌ AWS Speech Services connection failed`);
        }
    } catch (error) {
        console.log(`⚠️  AWS connection test error: ${error.message}`);
    }
});

// 优雅关闭
process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down gracefully...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    process.exit(0);
});